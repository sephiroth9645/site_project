<?php
	    include "connect.php";
            $sqlLogin = mysqli_query($con, "SELECT User_Name FROM user");

           	$row = mysqli_fetch_assoc($sqlLogin);
                 
            setcookie("user", $row["User_Name"]);
?>
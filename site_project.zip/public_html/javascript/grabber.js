	var selectedImage;
	function grabber(event, imgId){
	      if (selectedImage != undefined) {
		selectedImage.style.zIndex=5;

	}
	selectedImage=document.getElementById(imgId);
	selectedImage.style.zIndex=10;
	}
	function move(mouseEvent){
	      if(selectedImage){
		selectedImage.style.left = mouseEvent.clientX;
		selectedImage.style.top = mouseEvent.clientY;
		}
	}
	function dropper(event,imgId){
	           selectedImage.style.zIndex=5;
	           selectedImage = undefined;
}
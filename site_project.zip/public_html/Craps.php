<?php
	include "open_html.php";
?>
      <style type = "text/css">
         #seperateT   { text-align: right; margin-top: -250px; margin-left: 100px; margin-right: 100px;}
         div.red { color: red; margin-left: 100px; margin-right: 100px; }
      </style>
		<script src="javascript/Craps.js"></script>
	<?php
		include "htmlObody.php";
	?>
		
		<!--<form action = "">-->
			<table id="seperateT">
				<caption>
					Craps
				</caption>
				<tr>
					<td>
						Dice 1
					</td>
					<td>
						<input id="dice1" type="text" />
					</td>
				</tr>
				<tr>
					<td>
						Dice 2
					</td>
					<td>
						<input id="dice2" type="text" />
					</td>
				</tr>
				<tr>
					<td>
						Sum
					</td>
					<td>
						<input id="sum" type="text" />
					</td>
				</tr>
				<tr>
					<td>
						<input type="button" value="Roll Dice" onclick="play()" />
					</td>
				</tr>
			</table>
			<div id="status" class="red">
				Click the Roll Dice button to play!
			</div>
		</form>
	<?php
		include "htmlCbody.php";
	?>
<?php
	include "close_html.php";
?>
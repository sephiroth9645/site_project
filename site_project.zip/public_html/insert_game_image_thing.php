<?php
	include 'open_html.php';
?>
	<?php
		include 'htmlObody.php';
		include 'php_add_ons/stuff/connect.php';
		if(count($_FILES) > 0) {
			if(is_uploaded_file($_FILES['image']['tmp_name'])) {
				
				$imgData = addslashes(file_get_contents($_FILES['image']['tmp_name']));
				$imageProperties = getimagesize($_FILES['image']['tmp_name']);

				$sql = "INSERT INTO FF0(Image_Type, Image_Name) VALUES ('{$imageProperties['mime']}', '{$imgData}')";
				$current_id = mysqli_query($con, $sql);
			}
		}
	?>
		<form enctype="multipart/form-data" method="post">
			<input type="file" name="image" />
			<input type="submit" name="submit" value="submit" />
		</form>
	<?php
		include 'htmlCbody.php';
	?>
<?php
	include 'close_html.php';
?>
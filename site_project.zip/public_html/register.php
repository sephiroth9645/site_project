<?php
	include 'open_html.php';
?>
	<?php
		include 'htmlObody.php';
	?>
	<?php	
		include 'PHP_Classes/more_stuff/registration.php';	
	?>
		<form  enctype="multipart/form-data" method="post">
			<table class="register">
				<tr>
					<td>
						User Name:
					</td>
					<td>
						<input type="text" name="userName"/>
					</td>
				</tr>
				<tr>
					<td>
						Password:
					</td>
					<td>
						<input type="password" name="password1" />
					</td>
				</tr>
				<tr>
					<td>
						Reenter Password:
					</td>
					<td>
						<input type="password" name="password2" />
					</td>
				</tr>
				<tr>
					<td>
						Email:
					</td>
					<td>
						<input type="email" name="email" />
					</td>
				</tr>
				<tr>
					<td>
						Profile Image:
					</td>
					<td>
						<input type="file" name="image" />
					</td>
				</tr>
				<tr>
					<td>
						<label>
							<input type="checkbox" name="terms" /> By submitting your information you agree to the <a href="terms.php" id="login2">terms</a> and conditions.
						</label>
					</td>
				</tr>
				<tr>
					<td>
						<input type="submit" name="submit" value="submit" />
					</td>
				</tr>
			</table>
		</form>
	<?php
		include 'htmlCbody.php';
	?>
<?php
	include 'close_html.php';
?>
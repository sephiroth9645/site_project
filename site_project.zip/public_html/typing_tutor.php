<?php
	include "open_html.php";
?>
	<?php
		include "htmlObody.php";
	?>
	        <style type="text/css">
            #typing {
            	 margin-top: -300px;
                border-style: solid;
                border-color: red;
                border-width: 4px;
            }

            #display {
                width: 875px;
                height: 20px;
            }
            
            #firstRow{
            	margin-top: 10px;
            }
            
            #secondRow{
            	margin-left: 25px;
            }
            
            #thirdRow{
            	margin-left: 50px;
            }
            
          	#selectList {
    				margin-left: 400px;
    				margin-top: -290px;
				}
				
					#checkD{
            width: 875px;
            height: 20px;
					}
					
				#buttonCall{
					margin-left: 490px;
					margin-top: -30px;
				}
	</style>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js" type="text/javascript">
		</script>
		
		<script>
		
				$(document).ready(function(){

			$("input").keydown(function(event){

				if(event.which == "81"){
				    document.getElementById("button_q").style.backgroundColor = "blue";
				}

				if(event.which == "87"){
				    document.getElementById("button_w").style.backgroundColor = "purple";
				}

				if(event.which == "69"){
					document.getElementById("button_e").style.backgroundColor = "lightgrey";
				}

				if(event.which == "82"){
					document.getElementById("button_r").style.backgroundColor = "pink";
				}

				if(event.which == "84"){
					document.getElementById("button_t").style.backgroundColor = "green";
				}

				if(event.which == "89"){
					document.getElementById("button_y").style.backgroundColor = "green";
				}

				if(event.which == "73"){
					document.getElementById("button_i").style.backgroundColor = "green";
				}

				if(event.which == "79"){
					document.getElementById("button_o").style.backgroundColor = "green";
				}

				if(event.which == "80"){
					document.getElementById("button_p").style.backgroundColor = "green";
				}

				if(event.which == "65"){
					document.getElementById("button_a").style.backgroundColor = "green";
				}

				if(event.which == "83"){
					document.getElementById("button_s").style.backgroundColor = "green";
				}

				if(event.which == "85"){
					document.getElementById("button_u").style.backgroundColor = "green";
				}

				if(event.which == "68"){
					document.getElementById("button_d").style.backgroundColor = "green";
				}

				if(event.which == "70"){
					document.getElementById("button_f").style.backgroundColor = "green";
				}

				if(event.which == "71"){
					document.getElementById("button_g").style.backgroundColor = "green";
				}

				if(event.which == "72"){
					document.getElementById("button_h").style.backgroundColor = "green";
				}

				if(event.which == "74"){
					document.getElementById("button_j").style.backgroundColor = "green";
				}

				if(event.which == "75"){
					document.getElementById("button_k").style.backgroundColor = "green";
				}

				if(event.which == "76"){
					document.getElementById("button_l").style.backgroundColor = "green";
				}

				if(event.which == "59"){
					document.getElementById("button_;").style.backgroundColor = "green";
				}

				if(event.which == "90"){
					document.getElementById("button_z").style.backgroundColor = "green";
				}

				if(event.which == "88"){
					document.getElementById("button_x").style.backgroundColor = "green";
				}

				if(event.which == "67"){
					document.getElementById("button_c").style.backgroundColor = "green";
				}

				if(event.which == "86"){
					document.getElementById("button_v").style.backgroundColor = "green";
				}

				if(event.which == "66"){
					document.getElementById("button_b").style.backgroundColor = "green";
				}

				if(event.which == "78"){
					document.getElementById("button_n").style.backgroundColor = "green";
				}

				if(event.which == "77"){
					document.getElementById("button_m").style.backgroundColor = "green";
				}

				//$("div").html("Key " + event.which);
			    checkInput();
			});



			$("input").keyup(function(event){

				if(event.which == "81"){

					document.getElementById("button_q").style.backgroundColor = "lightgrey";

				}

				if(event.which == "87"){

					document.getElementById("button_w").style.backgroundColor = "lightgrey";

				}

				if(event.which == "69"){

					document.getElementById("button_e").style.backgroundColor = "lightgrey";

				}

				if(event.which == "82"){

					document.getElementById("button_r").style.backgroundColor = "lightgrey";

				}

				if(event.which == "84"){

					document.getElementById("button_t").style.backgroundColor = "lightgrey";

				}

				if(event.which == "89"){

					document.getElementById("button_y").style.backgroundColor = "lightgrey";

				}

				if(event.which == "73"){

					document.getElementById("button_i").style.backgroundColor = "lightgrey";

				}

				if(event.which == "79"){

					document.getElementById("button_o").style.backgroundColor = "lightgrey";

				}

				if(event.which == "80"){

					document.getElementById("button_p").style.backgroundColor = "lightgrey";

				}

				if(event.which == "65"){

					document.getElementById("button_a").style.backgroundColor = "lightgrey";

				}

				if(event.which == "83"){

					document.getElementById("button_s").style.backgroundColor = "lightgrey";

				}

				if(event.which == "85"){

					document.getElementById("button_u").style.backgroundColor = "lightgrey";

				}

				if(event.which == "68"){

					document.getElementById("button_d").style.backgroundColor = "lightgrey";

				}

				if(event.which == "70"){

					document.getElementById("button_f").style.backgroundColor = "lightgrey";

				}

				if(event.which == "71"){

					document.getElementById("button_g").style.backgroundColor = "lightgrey";

				}

				if(event.which == "72"){

					document.getElementById("button_h").style.backgroundColor = "lightgrey";

				}

				if(event.which == "74"){

					document.getElementById("button_j").style.backgroundColor = "lightgrey";

				}

				if(event.which == "75"){

					document.getElementById("button_k").style.backgroundColor = "lightgrey";

				}

				if(event.which == "76"){

					document.getElementById("button_l").style.backgroundColor = "lightgrey";

				}

				if(event.which == "59"){

					document.getElementById("button_;").style.backgroundColor = "lightgrey";

				}

				if(event.which == "90"){

					document.getElementById("button_z").style.backgroundColor = "lightgrey";

				}

				if(event.which == "88"){

					document.getElementById("button_x").style.backgroundColor = "lightgrey";

				}

				if(event.which == "67"){

					document.getElementById("button_c").style.backgroundColor = "lightgrey";

				}

				if(event.which == "86"){

					document.getElementById("button_v").style.backgroundColor = "lightgrey";

				}

				if(event.which == "66"){

					document.getElementById("button_b").style.backgroundColor = "lightgrey";

				}

				if(event.which == "78"){

					document.getElementById("button_n").style.backgroundColor = "lightgrey";

				}

				if(event.which == "77"){

					document.getElementById("button_m").style.backgroundColor = "lightgrey";

				}

			});



		});


		function selectLesson(){

			var lessons = document.getElementById("lessons").value;

			var less1 = document.getElementById("lessons").value = "lesson1";

			var less2 = document.getElementById("lessons").value = "lesson2";

			var id = document.getElementById("display");



			if(lessons == less1){

				id.value = lesson1();

			}



			if(lessons == less2){

				id.value = "I am almost their.";

			}

		}



		function lesson1(){

			var l1 = "asdf fd df as saa ssa dsd fdsa dsaf";

			return l1;

		}

		function checkInput() {
		    var lesson = document.valueOf("lesson");
		    var chkLesson = document.valueOf("checkD");

		    var patt = new RegExp(lesson);
		    var res = patt.toString(chkLesson);

		    if (patt == res) {
		        document.getElementById("checkD").style.backgroundColor = "green";
		    }
		    else if (patt != res) {
		        document.getElementById("checkD").style.backgroundColor = "red";
		    }
		    /*for (var i = 0; i <= lesson.length && i <= chkLesson.length; i++) {
		        if (lesson.charAt(i) == chkLesson.charAt(i)) {
		            alert("yay");
		        }
		        else {
		            alert("boo");
		        }
		    }*/
		}



    </script>
    
		<div id="typing">
            <h1 id="title">Typing Tutor</h1>
			<input type="text" id="display"/>	
			<br />
			<input type="text" id="checkD" />
			
			<div id="firstRow">	
				<input type="submit" id="button_q" value="q" style="width: 50px; height: 50px;" disabled="true"/>
				<input type="submit" id="button_w" value="w" style="width: 50px; height: 50px;" disabled="true"/>
				<input type="submit" id="button_e" value="e" style="width: 50px; height: 50px;" disabled="true"/>
				<input type="submit" id="button_r" value="r" style="width: 50px; height: 50px;" disabled="true"/>
				<input type="submit" id="button_t" value="t" style="width: 50px; height: 50px;" disabled="true"/>
				<input type="submit" id="button_y" value="y" style="width: 50px; height: 50px;" disabled="true"/>
				<input type="submit" id="button_u" value="u" style="width: 50px; height: 50px;" disabled="true"/>
				<input type="submit" id="button_i" value="i" style="width: 50px; height: 50px;" disabled="true"/>
				<input type="submit" id="button_o" value="o" style="width: 50px; height: 50px;" disabled="true"/>
				<input type="submit" id="button_p" value="p" style="width: 50px; height: 50px;" disabled="true"/>
			</div>			
			<div id="secondRow">
				<input type="submit" id="button_a" value="a" style="width: 50px; height: 50px;" disabled="true"/>
				<input type="submit" id="button_s" value="s" style="width: 50px; height: 50px;" disabled="true"/>
				<input type="submit" id="button_d" value="d" style="width: 50px; height: 50px;" disabled="true"/>
				<input type="submit" id="button_f" value="f" style="width: 50px; height: 50px;" disabled="true"/>
				<input type="submit" id="button_g" value="g" style="width: 50px; height: 50px;" disabled="true"/>
				<input type="submit" id="button_h" value="h" style="width: 50px; height: 50px;" disabled="true"/>
				<input type="submit" id="button_j" value="j" style="width: 50px; height: 50px;" disabled="true"/>
				<input type="submit" id="button_k" value="k" style="width: 50px; height: 50px;" disabled="true"/>
				<input type="submit" id="button_l" value="l" style="width: 50px; height: 50px;" disabled="true"/>
				<input type="submit" id="button_;" value=";" style="width: 50px; height: 50px;" disabled="true"/>
			</div>
			<div id="thirdRow">
				<input type="submit" id="button_z" value="z" style="width: 50px; height: 50px;" disabled="true"/>
				<input type="submit" id="button_x" value="x" style="width: 50px; height: 50px;" disabled="true"/>
				<input type="submit" id="button_c" value="c" style="width: 50px; height: 50px;" disabled="true"/>
				<input type="submit" id="button_v" value="v" style="width: 50px; height: 50px;" disabled="true"/>
				<input type="submit" id="button_b" value="b" style="width: 50px; height: 50px;" disabled="true"/>
				<input type="submit" id="button_n" value="n" style="width: 50px; height: 50px;" disabled="true"/>
				<input type="submit" id="button_m" value="m" style="width: 50px; height: 50px;" disabled="true"/>
				<input type="submit" id="button_," value="," style="width: 50px; height: 50px;" disabled="true"/>
				<input type="submit" id="button_." value="." style="width: 50px; height: 50px;" disabled="true"/>
			</div>
		</div>
		<div id="selectList">
			<select	name="lessons" id="lessons">
				<option value="lesson1">Lesson 1</option>
				<option value="lesson2">Lesson 2</option>
			</select>
		</div>
		<div id="buttonCall">
			<button type="button" onclick="selectLesson()" >select</button>
		</div>
	<?php
		include "htmlCbody.php";
	?>
<?php
	include "close_html.php";
?>
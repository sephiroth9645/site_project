<?php
	include "open_html.php";
?>
	<?php
		include "htmlObody.php";
	?>
			   <link rel="stylesheet" href="css/blueimp-gallery.min.css">
		<!-- The Gallery as lightbox dialog, should be a child element of the document body -->
		<div id="blueimp-gallery" class="blueimp-gallery">
    		<div class="slides"></div>
    		<h3 class="title"></h3>
    		<a class="prev">‹</a>
    		<a class="next">›</a>
    		<a class="close">×</a>
    		<a class="play-pause"></a>
    		<ol class="indicator"></ol>
		</div>
		<div id="links" style="margin-top: 40px; margin-left: 100px;">
			<a href="images/PS4/SHARE/Screenshots/Borderlands/Band.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Band.jpg" alt="Band" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Battle.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Battle.jpg" alt="Battle" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Behind.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Behind.jpg" alt="Behind" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Better.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Better.jpg" alt="Better" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Bombs.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Bombs.jpg" alt="Bombs" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Brain_Drain.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Brain_Drain.jpg" alt="Brain Drain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Bro.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Bro.jpg" alt="Bro" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Build.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Build.jpg" alt="Build" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Constructor.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Constructor.jpg" alt="Constructor" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Daddy.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Daddy.jpg" alt="Daddy" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Dead.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Dead.jpg" alt="Dead" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Dejaminated.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Dejaminated.jpg" alt="Dejaminated" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Digitize.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Digitize.jpg" alt="Digitized" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Divided.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Divided.jpg" alt="Divided" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Dragon_Slayer.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Dragon_Slayer.jpg" alt="Dragon_Slayer" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Drakensburg.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Drakensburg.jpg" alt="Drakensburg" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Duelist.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Duelist.jpg" alt="Duelist" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Easy.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Easy.jpg" alt="Easy" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Elementalist.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Elementalist.jpg" alt="Elementalist" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Explorer.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Explorer.jpg" alt="Explorer" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Explosive.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Explosive.jpg" alt="Explosive" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Farewell.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Farewell.jpg" alt="Farewell" />
    		</a>
			<a href="images/PS4/SHARE/Screenshots/Borderlands/Fashion.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Fashion.jpg" alt="Fashion" />
    		</a>
			<a href="images/PS4/SHARE/Screenshots/Borderlands/Flame.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Flame.jpg" alt="Flame" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Free.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Free.jpg" alt="Free" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Friendship.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Friendship.jpg" alt="Friendship" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Gesture.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Gesture.jpg" alt="Gesture" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Goliath.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Goliath.jpg" alt="Goliath" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Grab.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Grab.jpg" alt="Grab" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Guts.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Guts.jpg" alt="Guts" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Helios.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Helios.jpg" alt="Helios" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/High.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/High.jpg" alt="High" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/House.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/House.jpg" alt="House" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Improving.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Improving.jpg" alt="Improving" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/In_Town.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/In_Town.jpg" alt="In Town" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Invaders.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Invaders.jpg" alt="Invaders" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Limit.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Limit.jpg" alt="Limit" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Look.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Look.jpg" alt="Look" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Loot.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Loot.jpg" alt="Loot" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Lunar.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Lunar.jpg" alt="Lunar" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Merrif.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Merrif.jpg" alt="Merrif" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Money.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Money.jpg" alt="Money" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Moon_Master.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Moon_Master.jpg" alt="Moon Master" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Multi_Face.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Multi_Face.jpg" alt="Multi Face" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Pancake.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Pancake.jpg" alt="Pancake" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Plumber.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Plumber.jpg" alt="Plumber" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Recalled.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Recalled.jpg" alt="Recalled" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Road.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Road.jpg" alt="Road" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Rock.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Rock.jpg" alt="Rock" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Rookie.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Rookie.jpg" alt="Rookie" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Screamed.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Screamed.jpg" alt="Screamed" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Superior.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Superior.jpg" alt="Superior" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Theft.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Theft.jpg" alt="Theft" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands/Wish.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Borderlands/Wish.jpg" alt="Wish" />
    		</a>
		</div>
		<script src="javascript/blueimp-gallery.min.js"></script>
		<script>
			document.getElementById('links').onclick = function (event) {
    			event = event || window.event;
    			var target = event.target || event.srcElement,
         	link = target.src ? target.parentNode : target,
         	options = {index: link, event: event},
         	links = this.getElementsByTagName('a');
    			blueimp.Gallery(links, options);
			};
		</script>
	<?php
		include "htmlCbody.php";
	?>
<?php
	include "close_html.php";
?>
<?php
	include 'open_html.php';
?>
	<?php
		include 'htmlObody.php';
	?>
		<link rel="stylesheet" href="css/blueimp-gallery.min.css">
		<style type="text/css">
			.images {
    		width: 100px;
    		position: relative;
    		opacity: 0.75;
    		transition: 0.3s ease;
    		cursor: pointer;
			}

			.images:hover {
    		transform: scale(1.5, 1.5);
    		opacity: 1;
			}
		</style>
		<!-- The Gallery as lightbox dialog, should be a child element of the document body -->
		<div id="blueimp-gallery" class="blueimp-gallery">
    		<div class="slides"></div>
    		<h3 class="title"></h3>
    		<a class="prev">‹</a>
    		<a class="next">›</a>
    		<a class="close">×</a>
    		<a class="play-pause"></a>
    		<ol class="indicator"></ol>
		</div>
		<form>
		<div id="links" style="margin-top: 40px; margin-left: 100px;">
			<?php
				$directory = "images/PS4/SHARE/Screenshots/Borderlands_ The Handsome Collection/";
				$imageName = scandir($directory);
				$i = 0;
				$handle = opendir(dirname(realpath(__FILE__)).'/images/PS4/SHARE/Screenshots/Borderlands_ The Handsome Collection/');
        while($file = readdir($handle)){
            if($file !== '.' && $file !== '..'){
     ?>	
                <a href="images/PS4/SHARE/Screenshots/Borderlands_ The Handsome Collection/<?php echo $file; ?>" />
                	<img src="images/PS4/SHARE/Screenshots/Borderlands_ The Handsome Collection/<?php echo$file; ?>" alt="<?php while($i <= count($imageName)){echo $imageName[$i]; $i++;} ?>" class="images" />
                </a>
      <?php
            }
            $i++;
        }
			?>
		</div>
			<script src="javascript/blueimp-gallery.min.js"></script>
			<script>
				document.getElementById('links').onclick = function (event) {
    				event = event || window.event;
    				var target = event.target || event.srcElement,
    	     		link = target.src ? target.parentNode : target,
         		options = {index: link, event: event},
         		links = this.getElementsByTagName('a');
    				blueimp.Gallery(links, options);
				};
			</script>
		</form>
	<?php
		include 'htmlCbody.php';
	?>
<?php
	include 'close_html.php';
?>
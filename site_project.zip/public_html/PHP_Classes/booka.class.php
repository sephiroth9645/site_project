<?php
	class Books
	{
			private $bookName;
			private $bookAuthor;
			private $publish;
			
			const USER = "a8068632_root";
			const SERVER = "mysql13.000webhost.com";
			const PASS = "mCastro131";
			const DB = "a8068632_info";
			
			private $insertBook;			
			
			function __construct($name, $author, $publishD)
			{
					$this->bookName = $name;
					$this->bookAuthor = $author;
					$this->publish = $publishD;
					
					$this->query = mysqli_connect(self::SERVER, self::USER, self::PASS, self::DB);
					
					if(mysqli_connect_errno())
					{
						echo "Failed to connect to database. ". mysqli_connect_error();
					}
			}
			
			function setBookName($name)
			{
					$this->bookName = $name;
			}
			
			function setAuthorName($author)
			{
					$this->bookAuthor = $author;
			}
			
			function setPublishDate($publishD)
			{
					$this->publish = $publishD;
			}
			
			function getInsertBook($name, $author, $publishD)
			{
				$this->bookName = $name;
				$this->bookAuthor = $author;
				$this->publish = $publishD;
				
				$insertBook = mysqli_query($this->query, "INSERT INTO Books(Book_Title, Book_Author, Publish_Date) VALUES ('$this->bookName','$this->bookAuthor','$this->publish')");
			}
	}
?>
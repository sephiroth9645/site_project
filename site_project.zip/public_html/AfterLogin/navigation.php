<div id="mySideNav" class="sideNav">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
    <a href="index.cshtml">Home</a>
    <a href="questing.php">Create Character</a>
    <a href="startGame.php">Start Game</a>
    <a href="comment.php">Forum</a>
    <a href="#">PS4 Screenshots</a>
    <a href="#">Xbox One Screenshots</a>
    <a href="#">PC Screenshots</a>
    <a href="#">PS4 Video Clips</a>
    <a href="#">Xbox One Video Clips</a>
    <a href="#">PC Video Clips</a>
    <a href="logout.php">Logout</a>
</div>

<div id="main">
    <h1>Stealth Games</h1>
    <div id="navigate">
        <span style="font-size: 30px; margin-top: 25px; cursor: pointer;" onclick="openNav()">Navigation</span>
    </div>

<?php
	include "open_html.php";
?>
	<?php
		include "htmlObody.php";
	?>
		<link rel="stylesheet" href="css/blueimp-gallery.min.css">
		<!-- The Gallery as lightbox dialog, should be a child element of the document body -->
		<div id="blueimp-gallery" class="blueimp-gallery">
    		<div class="slides"></div>
    		<h3 class="title"></h3>
    		<a class="prev">‹</a>
    		<a class="next">›</a>
    		<a class="close">×</a>
    		<a class="play-pause"></a>
    		<ol class="indicator"></ol>
		</div>
		<div id="links" style="margin-top: 40px; margin-left: 100px;">
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Barret.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Barret.jpg" alt="Charity" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Blood.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Blood.jpg" alt="Domination" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Boom.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Boom.jpg" alt="Executioner" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Breaking.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Breaking.jpg" alt="Hunter" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Cannon.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Cannon.jpg" alt="Magic" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Chocochampion.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Chocochampion.jpg" alt="Marks" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Cross-Dresser.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Cross-Dresser.jpg" alt="Mission" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Demons.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Demons.jpg" alt="Recruit" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Disintegrator.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Disintegrator.jpg" alt="Skirmish" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Emerald.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Emerald.jpg" alt="Slayer" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Failure.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Failure.jpg" alt="Souls" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Fortune.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Fortune.jpg" alt="Terror" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Highwind.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Highwind.jpg" alt="Cain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Hojo.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Hojo.jpg" alt="Cain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/HQ.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/HQ.jpg" alt="Cain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Join.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Join.jpg" alt="Cain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Leveling.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Leveling.jpg" alt="Cain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Light.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Light.jpg" alt="Cain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Maker.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Maker.jpg" alt="Cain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Mastermind.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Mastermind.jpg" alt="Cain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Midgar.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Midgar.jpg" alt="Cain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Pain.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Pain.jpg" alt="Cain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Power.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Power.jpg" alt="Cain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Punch.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Punch.jpg" alt="Cain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Red.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Red.jpg" alt="Cain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Rescue.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Rescue.jpg" alt="Cain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Romance.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Romance.jpg" alt="Cain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Saftey.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Saftey.jpg" alt="Cain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Slashes.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Slashes.jpg" alt="Cain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Snake.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Snake.jpg" alt="Cain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Summoner.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Summoner.jpg" alt="Cain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Suprise.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Suprise.jpg" alt="Cain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Tricked.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Tricked.jpg" alt="Cain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Valentine.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Valentine.jpg" alt="Cain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Warning.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Warning.jpg" alt="Cain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Waves.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Waves.jpg" alt="Cain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Wings.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Wings.jpg" alt="Cain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Zero.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/Zero.jpg" alt="Cain" />
    		</a>
		</div>
		<script src="javascript/blueimp-gallery.min.js"></script>
		<script>
			document.getElementById('links').onclick = function (event) {
    			event = event || window.event;
    			var target = event.target || event.srcElement,
         	link = target.src ? target.parentNode : target,
         	options = {index: link, event: event},
         	links = this.getElementsByTagName('a');
    			blueimp.Gallery(links, options);
			};
		</script>
	<?php
		include "htmlCbody.php";
	?>
<?php
	include "close_html.php";
?>
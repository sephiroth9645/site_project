<?php
    include "open_html.php";
?>
    <?php
        include "htmlObody.php";
    ?>
				<table class="resume">
					<tr>
						<td>
							Michael Castro
						</td>
					</tr>
					<tr>
						<td>
							Inquirer about address.
						</td>
					</tr>
					<tr>
						<td>
							Cell: (385) 202 4853&nbsp;&nbsp;Email: michael.forrest.castro@gmail.com
						</td>
					</tr>
					<tr>
						<td>
							Profile
						</td>
					</tr>
					<tr>
						<td>
							Information Technology Professional: highly skilled in the computer sciences with outstanding time management skills. Fluent in JAVA, C#, and HTML5: known for attention to detail and strong work ethic.
						</td>
					</tr>
					<tr>
						<td>
							Skills {Years of experience}
						</td>
					</tr>
					<tr>
						<td>
							<ul>
								<li>
									HTML5 {5 years}
								</li>
								<li>
									Python {2 years}
								</li>
								<li>
									PHP {5 years}
								</li>
								<li>
									Ruby on Rails {1 year}
								</li>
								<li>
									ASP.net C# {4 years}
								</li>
								<li>
									Linux {3 years}
								</li>
								<li>
									Microsoft Server R2 2012 {2 years}
								</li>
							</ul>
						</td>
						<td>
							<ul>
								<li>
									Microsoft Share Point {1 year}
								</li>
								<li>
									Microsoft Multipoint Server {1 year}
								</li>
								<li>
									Microsoft Lync Server {1 year}
								</li>
								<li>
									Office 365 {1 year}
								</li>
								<li>
									VoIP SNOM 710 - 720 Support {1 year}
								</li>
								<li>
									Windows desktop top support {2 years}
								</li>
							</ul>
						</td>
						<td>
							<ul>
								<li>
									JQuery {2 years}
								</li>
								<li>
									JAVA {3 years}
								</li>
								<li>
									Android Development {2 years}
								</li>
								<li>
									MySQL {3 years}
								</li>
								<li>
									SQL {3 years}
								</li>
								<li>
									C++ {2 years}
								</li>
							</ul>
						</td>
					</tr>
					<tr>
						<td>
							Education
						</td>					
					</tr>
					<tr>
						<td>
							Bachelors of Software Development
						</td>
						<td>
							To be determined.
						</td>
					</tr>
					<tr>
						<td>
							ITT Technical Institute, Murray UT
						</td>
					</tr>
					<tr>
						<td>
							Associates of Software Development
						</td>
						<td>
							June 2012
						</td>
					</tr>
					<tr>
						<td>
							ITT Technical Institute, Murray UT
						</td>
						<td>
							GPA 3.45
						</td>
					</tr>
					<tr>
						<td>
							Employment
						</td>
					</tr>
					<tr>
						<td>
							Max Technologies
						</td>
						<td>
							East Carbon City, Utah
						</td>
						<td>
							October 2015 - November 2015
						</td>
					</tr>
					<tr>
						<td>
							Network Engineer
						</td>
					</tr>
					<tr>
						<td class="employment">
							<ul>
								<li>
									Network cable drops
								</li>
								<li>
									Diagnose computer problems
								</li>
           <li>
            	install Software
           </li>								
							</ul>
						</td>
					</tr>
					<tr>
						<td>
							Ray & Rae Enterprises
						</td>
						<td>
							Brigham City, Utah
						</td>
						<td>
							July 2014 - July 2015
						</td>
					</tr>
					<tr>
						<td>
							Network Engineer
						</td>
					</tr>
					<tr>
						<td class="employment">
							<ul>
								<li>
									Link clients desktops to the network domain.
								</li>
								<li>
									Configure SNOM 710 - 720 phones through Active Directory.
								</li>
								<li>
									Manage Microsoft Active Directory services.
								</li>
								<li>
									Manage Microsoft Sharepoint.
								</li>
								<li>
									Mount projectors, and install HDMI wall plates that use cat5 network technology.
								</li>
								<li>
									Manage Microsoft Multipoint servers, and thin clients.
								</li>
								<li>
									Virus, adware, and maleware removal.
								</li>
								<li>
									Manage Sonic Firewall.
								</li>
								<li>
									Set up network printers.
								</li>
								<li>
									Develop applications.
								</li>
							</ul>							
						</td>
					</tr>
					<tr>
						<td>
							Deseret Industries
						</td>
						<td>
							West Valley City, Utah
						</td>
						<td>
							April 2014 - July 2014
						</td>
					</tr>
					<tr>
						<td>
							Customer Representative
						</td>
					</tr>
					<tr>
						<td class="employment">
							<ul>
								<li>
									Place items from carts, onto shelves.
								</li>
								<li>
									Take customer orders for collectibles.
								</li>
								<li>
									Take customer orders for large items, and help load items into their vehicles.
								</li>
							</ul>
						</td>
					</tr>
					<tr>
						<td>
							VitalBGS
						</td>
						<td>
							Salt Lake City, Utah
						</td>
						<td>
							November 2013 - December 2013
						</td>
					</tr>
					<tr>
						<td>
							Web Developer
						</td>
					</tr>
					<tr>
						<td class="employment">
							<ul>
								<li>
									Update web sites, using mock up designs for the final result.
								</li>
								<li>
									Work with other developers, and helped them if they needed anything.
								</li>
							</ul>
						</td>
					</tr>
					<tr>
						<td>
							Discover
						</td>
						<td>
							Salt Lake City, Utah
						</td>
						<td>
							April 2013 - November 2013
						</td>
					</tr>
					<tr>
						<td>
							Operator
						</td>
					</tr>
					<tr>
						<td class="employment">
							<ul>
								<li>
									Insert fliers into machine.
								</li>
								<li>
									Diagnose machine when it broke down.
								</li>
							</ul>
						</td>
					</tr>
					<tr>
						<td>
							Xerox ACS
						</td>
						<td>
							Salt Lake City, Utah
						</td>
						<td>
							October 2012 - November 2012
						</td>
					</tr>
					<tr>
						<td>
							Customer Representative
						</td>
					</tr>
					<tr>
						<td class="employment">
							<ul>
								<li>
									Take inbound calls.
								</li>
								<li>
									Help the customer as much as I could with their problem.
								</li>
							</ul>
						</td>
					</tr>
					<tr>
						<td>
							The Village Site
						</td>
						<td>
							Sandy, Utah
						</td>
						<td>
							May 2011 - September 2013
						</td>
					</tr>
					<tr>
						<td>
							Web Developer
						</td>
					</tr>
					<tr>
						<td class="employment">
							<ul>
								<li>
									Work on given web pages for the web site.
								</li>
								<li>
									Help the back, and front end developers.
								</li>
							</ul>
						</td>
					</tr>
					<tr>
						<td>
							ITT Technical Institute
						</td>
						<td>
							Murray, Utah
						</td>
						<td>
							May 2010 - June 2012
						</td>
					</tr>
					<tr>
						<td>
							Tutor
						</td>
					</tr>
					<tr>
						<td class="employment">
							<ul>
								<li>
									Help fellow class mates with run time, logic, and compile errors.
								</li>
								<li>
									Managed 5 people per team, for projects.
								</li>
							</ul>
						</td>
					</tr>
					<tr>
						<td>
							Walmart
						</td>
						<td>
							Murray, Utah
						</td>
						<td>
							August 2010 - March 2011
						</td>
					</tr>
					<tr>
						<td>
							Courtesy Associate
						</td>
					</tr>
					<tr>
						<td class="employment">
							<ul>
								<li>
									Bring grocery carts back to the building in a timely manner.
								</li>
								<li>
									Help people with loading their things into cars.
								</li>
								<li>
									Greet customers in a friendly tone.
								</li>
							</ul>
						</td>
					</tr>
					<tr>
						<td>
							Convergys
						</td>
						<td>
							Murray, Utah
						</td>
						<td>
							May 2010 - July 2010
						</td>
					</tr>
					<tr>
						<td>
							Customer Representative
						</td>
					</tr>
					<tr>
						<td class="employment">
							<ul>
								<li>
									Take inbound calls.
								</li>
							</ul>
						</td>
					</tr>
				</table>
    <?php
        include "htmlCbody.php";
    ?>
<?php
   include "close_html.php";
?>

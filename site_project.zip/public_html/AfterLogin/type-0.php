<?php
	include "open_html.php";
?>
	<?php
		include "htmlObody.php";
	?>
		<link rel="stylesheet" href="css/blueimp-gallery.min.css">
		<!-- The Gallery as lightbox dialog, should be a child element of the document body -->
		<div id="blueimp-gallery" class="blueimp-gallery">
    		<div class="slides"></div>
    		<h3 class="title"></h3>
    		<a class="prev">‹</a>
    		<a class="next">›</a>
    		<a class="close">×</a>
    		<a class="play-pause"></a>
    		<ol class="indicator"></ol>
		</div>
		<div id="links" style="margin-top: 40px; margin-left: 100px;">
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Charity.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Charity.jpg" alt="Charity" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Domination.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Domination.jpg" alt="Domination" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Executioner.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Executioner.jpg" alt="Executioner" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Hunter.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Hunter.jpg" alt="Hunter" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Magic.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Magic.jpg" alt="Magic" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Marks.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Marks.jpg" alt="Marks" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Mission.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Mission.jpg" alt="Mission" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Recruit.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Recruit.jpg" alt="Recruit" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Skirmish.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Skirmish.jpg" alt="Skirmish" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Slayer.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Slayer.jpg" alt="Slayer" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Souls.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Souls.jpg" alt="Souls" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Terror.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Terror.jpg" alt="Terror" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Tiger.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Tiger.jpg" alt="Cain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/War.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/War.jpg" alt="Cain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/White_Tiger.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/White_Tiger.jpg" alt="Cain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Wrangler.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Wrangler.jpg" alt="Cain" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Zero.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/Zero.jpg" alt="Cain" />
    		</a>
		</div>
		<script src="javascript/blueimp-gallery.min.js"></script>
		<script>
			document.getElementById('links').onclick = function (event) {
    			event = event || window.event;
    			var target = event.target || event.srcElement,
         	link = target.src ? target.parentNode : target,
         	options = {index: link, event: event},
         	links = this.getElementsByTagName('a');
    			blueimp.Gallery(links, options);
			};
		</script>
	<?php
		include "htmlCbody.php";
	?>
<?php
	include "close_html.php";
?>
<?php
	include "open_html.php";
?>
	<?php
		include "htmlObody.php";
	?>
	   <link rel="stylesheet" href="css/blueimp-gallery.min.css">
		<p id="p2">
						To view all my screen shots please <a href="display_screenshots.php">click here!</a>
		</p>
		<!-- The Gallery as lightbox dialog, should be a child element of the document body -->
		<div id="blueimp-gallery" class="blueimp-gallery">
    		<div class="slides"></div>
    		<h3 class="title"></h3>
    		<a class="prev">‹</a>
    		<a class="next">›</a>
    		<a class="close">×</a>
    		<a class="play-pause"></a>
    		<ol class="indicator"></ol>
		</div>
		<div id="links">
    		<a href="images/PS4/SHARE/Screenshots/Diablo III_Reaper of Souls_Ultimate Evil Edition (English)/Diablo III_ Reaper of Souls_Ultimate Evil Edition (English)_20141214150416_1.jpg" title="Diablo 3">
        		<img height="300px" width="300px" src="images/PS4/SHARE/Screenshots/Diablo III_Reaper of Souls_Ultimate Evil Edition (English)/Diablo III_ Reaper of Souls_Ultimate Evil Edition (English)_20141214150416_1.jpg" alt="Diablo 3" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Dying Light/Dying Light_20150327201638.jpg" title="Dying Light">
        		<img width="300px" height="300px" src="images/PS4/SHARE/Screenshots/Dying Light/Dying Light_20150327201638.jpg" alt="Dying Light" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Just Cause 3/Enjoy_Homecoming.jpg" title="Just Cause 3">
        		<img width="300px" height="300px" src="images/PS4/SHARE/Screenshots/Just Cause 3/Enjoy_Homecoming.jpg" alt="Just Cause 3" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/FINAL FANTASY VII_20160111104005.jpg" title="Final Fantasy VII">
    			<img width="300px" height="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY VII/FINAL FANTASY VII_20160111104005.jpg" alt="Final Fantasy VII" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/Destiny_20150926214803.jpg" title="Destiny: Turtle?">
    			<img width="300 px" height="300 px" src="images/PS4/SHARE/Screenshots/Destiny/Destiny_20150926214803.jpg" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/The Witcher 3_ Wild Hunt/Velen_20.jpg" title="Hunting Fiend">
				<img width="300 px" height="300 px" src="images/PS4/SHARE/Screenshots/The Witcher 3_ Wild Hunt/Velen_20.jpg" alt="Feind" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Grand Theft Auto V/Grand Theft Auto V_20160109010014.jpg" title="Grand Theft Auto 5">
    			<img width="300px" height="300px" src="images/PS4/SHARE/Screenshots/Grand Theft Auto V/Grand Theft Auto V_20160109010014.jpg" alt="Over looking bay"/>
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Far Cry 4/Far Cry 4_20150928173852.jpg" title="Far Cry 4">
    			<img width="300px" height="300px" src="images/PS4/SHARE/Screenshots/Far Cry 4/Far Cry 4_20150928173852.jpg" alt="Flying." />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Borderlands_ The Handsome Collection/Borderlands_ The Handsome Collection_20150517183238.jpg" title="Borderloands The Handsome Collection">
    			<img width="300px" height="300px" src="images/PS4/SHARE/Screenshots/Borderlands_ The Handsome Collection/Borderlands_ The Handsome Collection_20150517183238.jpg" alt="Elemenatal" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/FINAL FANTASY TYPE-0 HD_20150428230415.jpg" title="Final Fantasy Type-0 HD">
    			<img width="300px" height="300px" src="images/PS4/SHARE/Screenshots/FINAL FANTASY TYPE-0 HD/FINAL FANTASY TYPE-0 HD_20150428230415.jpg" alt="Stick em up!" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Gauntlet/Gauntlet_20151220141538.jpg" title="Gauntlet">
    			<img width="300px" height="300px" src="images/PS4/SHARE/Screenshots/Gauntlet/Gauntlet_20151220141538.jpg" alt="Khamun" />
    		</a>
     		<a href="images/PS4/SHARE/Screenshots/MAGICKA 2/MAGICKA 2_20160107184205.jpg" title="Magicka 2: Killing Innocents.">
    			<img width="300px" height="300px" src="images/PS4/SHARE/Screenshots/MAGICKA 2/MAGICKA 2_20160107184205.jpg" alt="Killing Innocents" />
    		</a>
     		<a href="" title="">
    			<img width="300px" height="300px" src="" alt="" />
    		</a>
     		<a href="" title="">
    			<img width="300px" height="300px" src="" alt="" />
    		</a>
    		<a href="" title="">
    			<img width="300px" height="300px" src="" alt="" />
    		</a>
    		<a href="" title="">
    			<img width="300px" height="300px" src="" alt="" />
    		</a>
		</div>
		<script src="javascript/blueimp-gallery.min.js"></script>
		<script>
			document.getElementById('links').onclick = function (event) {
    			event = event || window.event;
    			var target = event.target || event.srcElement,
         	link = target.src ? target.parentNode : target,
         	options = {index: link, event: event},
         	links = this.getElementsByTagName('a');
    			blueimp.Gallery(links, options);
			};
		</script>
	<?php
		include "htmlCbody.php";
	?>
<?php
	include "close_html.php";
?>
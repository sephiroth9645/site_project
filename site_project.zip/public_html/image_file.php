<?php
	$conn = mysql_connect("mysql13.000webhost.com", "a8068632_root", "mCastro131");
	mysql_select_db("a8068632_info") or die(mysql_error());
	if(isset($_GET['ID'])) {
		$sql = "SELECT type, Game_Image FROM game_image WHERE ID=" . $_GET['ID'];
		$result = mysql_query("$sql") or die("<b>Error:</b> Problem on Retrieving Image BLOB<br/>" . mysql_error());
		$row = mysql_fetch_array($result);
		header("Content-type: " . $row["type"]);
		echo $row["Game_Image"];
	}
	mysql_close($conn);
?>
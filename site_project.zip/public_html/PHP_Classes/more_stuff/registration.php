<?php	
	if(count($_FILES) > 0 && isset($_POST['terms'])) {
		if(is_uploaded_file($_FILES['image']['tmp_name'])) {
			
			include '././php_add_ons/stuff/connect.php';
				$password1 = $_POST['password1'];
				$password2 = $_POST['password2'];
				
				$imgData = addslashes(file_get_contents($_FILES['image']['tmp_name']));
				$imageProperties = getimagesize($_FILES['image']['tmp_name']);
						
				if($password1 == $password2)
				{
					$user = $_POST['userName'];
					$userImage = $_POST['userName'];
					$password = $_POST['password1'];
					$email = $_POST['email'];
					if(isset($user) && !empty($user) && isset($email) && !empty($email)){
						if(!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/", $email)){
    				// Return Error - Invalid Email
    					$msg = 'The email you have entered is invalid, please try again.';
					}
					else{
					$check = mysqli_query($con, "SELECT * FROM create_user");
					$checkUser = mysqli_fetch_assoc($check);
					if($user == $checkUser['user_Name'] || $email == $checkUser['user_Email']){
        			echo "The user name or email is already registered.";
         }
					else{
						$sql = mysqli_query($con, "INSERT INTO create_user(user_Name, image_Name, user_Password, user_Email, user_Image_Type, user_Image) VALUES ('$user', '$userImage', md5('$password'), '$email', '{$imageProperties['mime']}', '{$imgData}')");
						//$current_id = mysqli_query($con, $sql) or die("<b>Error:</b> Problem on Insert information<br/>" . mysqli_error($con));

        $sqlLogin = mysqli_query($con, "SELECT user_Name, user_Password FROM create_user WHERE User_Name = '$user' AND User_Password =  md5('$password')");				     
        if(mysqli_num_rows($sqlLogin) == 1){
        		$row = mysqli_fetch_assoc($sqlLogin);
        	  					 
          setcookie("user", $row["user_Name"]);
          header ("Location: ././AfterLogin/index.php");
         }
        	}
        }
				  }
			}
				else {
					Echo "Your passwords did not match.";
				}
	}
	}else {
		echo "You must accept the terms.";
}
?>

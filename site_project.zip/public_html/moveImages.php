<?php
	include "open_html.php";
?>
	<script scr="javascript/grabber.js"></script>
	<?php
		include "htmlObody.php";
	?>
		<form onmousemove="move(event);" onmouseup="dropper();">
			<img src="#" alt="#" />
			<img src="#" alt="#" />
			<img src="#" alt="#" />
			<img src="#" alt="#" />
		</form>
	<?php
		include "htmlCbody.php";
	?>
<?php
	include "close_html.php";
?>
<?php
?>
<!DOCTYP htlm>
   <html>
      <body>
         <div>
            Michael Castro
            <div>
            </div>
         </div>
         <div>
	   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;I graduated from ITT-TECHNICAL Institute in 2012. Almost honors, 3.45 GPA.
           <br />
           I've learned multiple programming languages. PHP, HTML5, C++, C#, ASP.NET, JAVA, javascript with the
           <br />
           frame work JQuery. I have one year left in my bachelor degree program. I chose programming becuase it
	   <br /> 
           allows me to be challenged on a logical level. I also find programming interesting. For myself its like
           <br />
           math. It comes easy to me, and if I am stuck on a problem then I will sit thier and play with it until
           <br />
           I figured it out. I am more a one man team. It will take me about two months of learning a language to
           <br />
           become fluent in it. I am slow at first, becuase I am trying to learn the way your code is set up, and
           <br />
           try to quickly get the updates you need me to up and running.  
         </div>
         <div>
            <a href="http://localhost:50549/Index.aspx" > ASP.NET site</a>
         </div>
      </body>
   </html>

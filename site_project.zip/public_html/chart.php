<?php
	include "open_html.php";
?>
	<?php
		include "htmlObody.php";
	?>
		<?php
			readfile("Projects/JAVA/MathChart/src/mathchart/MathChart.java");
		?>
	<?php
		include "htmlCbody.php";
	?>
<?php
	include "close_html.php";
?>
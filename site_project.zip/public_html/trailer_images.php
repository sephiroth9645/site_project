<?php
	include "open_html.php";
?>
	<?php
		include "htmlObody.php";
	?>
	   <link rel="stylesheet" href="css/blueimp-gallery.min.css">
		<!-- The Gallery as lightbox dialog, should be a child element of the document body -->
		<div id="blueimp-gallery" class="blueimp-gallery">
    		<div class="slides"></div>
    		<h3 class="title"></h3>
    		<a class="prev">‹</a>
    		<a class="next">›</a>
    		<a class="close">×</a>
    		<a class="play-pause"></a>
    		<ol class="indicator"></ol>
		</div>
		<div id="links" style="margin-top: -225px; margin-left: 100px;">
    		<a href="images/designs/2016-05-26.png" title="1st">
        		<img width="300px" src="images/designs/2016-05-26.png" alt="1st" />
    		</a>
    		<a href="images/designs/2016-05-26-1.png" title="1st">
    			<img width="300px" src="images/designs/2016-05-26-1.png" alt="1st" />
    		</a>
    		<a href="images/designs/2016-05-26-2.png" title="1st">
    		   <img width="300px" src="images/designs/2016-05-26-2.png" alt="1st" />
    		</a>
    		<a href="images/designs/2016-05-26-3.png" title="1st">
        		<img width="300px" src="images/designs/2016-05-26-3.png" alt="1st" />
    		</a>
    		<a href="images/designs/2016-05-26-4.png" title="1st">
    			<img width="300px" src="images/designs/2016-05-26-4.png" alt="1st" />
    		</a>
    		<a href="images/designs/2016-05-26-5.png" title="1st">
    		   <img width="300px" src="images/designs/2016-05-26-5.png" alt="1st" />
    		</a>
    		<a href="images/designs/2016-05-26-6.png" title="1st">
        		<img width="300px" src="images/designs/2016-05-26-6.png" alt="1st" />
    		</a>
    		<a href="images/designs/2016-05-26-7.png" title="1st">
    			<img width="300px" src="images/designs/2016-05-26-7.png" alt="1st" />
    		</a>
    		<a href="images/designs/2016-05-26-8.png" title="1st">
    		   <img width="300px" src="images/designs/2016-05-26-8.png" alt="1st" />
    		</a>
    		<a href="images/designs/2016-06-15.png" title="2nd">
        		<img width="300px" src="images/designs/2016-06-15.png" alt="2nd" />
    		</a>
    		<a href="images/designs/2016-06-15-1.png" title="2nd">
    			<img width="300px" src="images/designs/2016-06-15-1.png" alt="2nd" />
    		</a>
    		<a href="images/designs/2016-06-15-2.png" title="2nd">
    		   <img width="300px" src="images/designs/2016-06-15-2.png" alt="2nd" />
    		</a>
    		<a href="images/designs/2016-06-15-3.png" title="2nd">
        		<img width="300px" src="images/designs/2016-06-15-3.png" alt="2nd" />
    		</a>
    		<a href="images/designs/2016-06-15-4.png" title="2nd">
    			<img width="300px" src="images/designs/2016-06-15-4.png" alt="2nd" />
    		</a>
    		<a href="images/designs/2016-06-15-5.png" title="2nd">
    		   <img width="300px" src="images/designs/2016-06-15-5.png" alt="2nd" />
    		</a>
    		<a href="images/designs/2016-06-15-6.png" title="2nd">
        		<img width="300px" src="images/designs/2016-06-15-6.png" alt="2nd" />
    		</a>
    		<a href="images/designs/2016-06-15-7.png" title="2nd">
    			<img width="300px" src="images/designs/2016-06-15-7.png" alt="2nd" />
    		</a>
    		<a href="images/designs/2016-06-15-8.png" title="2nd">
    		   <img width="300px" src="images/designs/2016-06-15-8.png" alt="2nd" />
    		</a>
    		<a href="images/designs/2016-06-15-9.png" title="2nd">
    		   <img width="300px" src="images/designs/2016-06-15-9.png" alt="2nd" />
    		</a>
		</div>
		<script src="javascript/blueimp-gallery.min.js"></script>
		<script>
			document.getElementById('links').onclick = function (event) {
    			event = event || window.event;
    			var target = event.target || event.srcElement,
         	link = target.src ? target.parentNode : target,
         	options = {index: link, event: event},
         	links = this.getElementsByTagName('a');
    			blueimp.Gallery(links, options);
			};
		</script>
	<?php
		include "htmlCbody.php";
	?>
<?php
	include "close_html.php";
?>
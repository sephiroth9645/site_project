<?php
	include 'open_html.php';
?>
	<?php
		include 'htmlObody.php';
	?>
		<table id="books">
			<?php
				include 'php_add_ons/stuff/connect.php';
				
				$sql = "SELECT * FROM Movies ORDER BY Movie_Title";
				
				$result = mysqli_query($con, $sql);
				
				while($row = mysqli_fetch_assoc($result)){
			?>
			<tr>
				<td>
					<?php echo $row['Movie_Title']; ?>
				</td>
				<td>
					<?php echo $row['Movie_Producer']; ?>
				</td>
				<td>
					<?php echo $row['Movie_Director']; ?>
				</td>
				<td>
					<?php echo $row['Release_Date']; ?>
				</td>
			</tr>
			<?php
				}
			?>
		</table>
	<?php
		include 'htmlCbody.php';
	?>
<?php
	include 'close_html.php';
?>
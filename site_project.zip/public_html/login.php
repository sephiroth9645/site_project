<?php
	include "open_html.php";
?>
	<?php
		include "htmlObody.php";
	?>
		<?php
			include "PHP_Classes/more_stuff/Login.class.php";


			if(isset($_POST['submit'])){
					
				$user = $_POST['user_name'];
				$pass = $_POST['password'];
				
				$login = new Login($user, $pass);
				
				$login->getLoginInformation($user, $pass);
			}
		?>
			<form method="post">
				<table class="login">
				<tr>
					<td>
						User Name:
					</td>
					<td>
						<input type="text" name="user_name" />
					</td>
				</tr>
				<tr>
					<td>
						Password:
					</td>
					<td>
						<input type="password" name="password" />
					</td>
				</tr>
				<tr>
					<td>
						<input type="submit" name="submit" value="submit" />
					</td>
				</tr>
			</table>
			<div id="login">
				If you have not registered please <a href="register.php" id="login2">create user</a> here.
			</div>
		</form>
	<?php
		include "htmlCbody.php";
	?>
<?php
	include "close_html.php";
?>
<?php
?>
      <body>
      	<canvas id="hdCanvas">
            Your browswer does not support canvas.
        </canvas>
        <?php
        		include "navigation.php";
        ?>
			<div id="log" >
				<?php
					include "user_name.php";
				?>
			</div>
<?php
	include "open_html.php";
?>
	<?php
		include "htmlObody.php";
	?>
		<link rel="stylesheet" href="css/blueimp-gallery.min.css">
		<!-- The Gallery as lightbox dialog, should be a child element of the document body -->
		<div id="blueimp-gallery" class="blueimp-gallery">
    		<div class="slides"></div>
    		<h3 class="title"></h3>
    		<a class="prev">‹</a>
    		<a class="next">›</a>
    		<a class="close">×</a>
    		<a class="play-pause"></a>
    		<ol class="indicator"></ol>
		</div>
		<div id="links" style="margin-top: 40px; margin-left: 100px;">
    		<a href="images/PS4/SHARE/Screenshots/Grand Theft Auto V/Airfield.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Grand Theft Auto V/Airfield.jpg" alt="Airfield" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Grand Theft Auto V/Collected.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Grand Theft Auto V/Collected.jpg" alt="Collected" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Grand Theft Auto V/Jet.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Grand Theft Auto V/Jet.jpg" alt="Jet" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Grand Theft Auto V/Live.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Grand Theft Auto V/Live.jpg" alt="Live" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Grand Theft Auto V/Over.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Grand Theft Auto V/Over.jpg" alt="Over" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Grand Theft Auto V/Over2.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Grand Theft Auto V/Over2.jpg" alt="Over 2" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Grand Theft Auto V/Over3.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Grand Theft Auto V/Over3.jpg" alt="Over 3" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Grand Theft Auto V/Snow.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Grand Theft Auto V/Snow.jpg" alt="Snow" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Grand Theft Auto V/Snow2.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Grand Theft Auto V/Snow2.jpg" alt="Snow 2" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Grand Theft Auto V/Snow3.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Grand Theft Auto V/Snow3.jpg" alt="Snow 3" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Grand Theft Auto V/snow4.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Grand Theft Auto V/snow4.jpg" alt="Snow 4" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Grand Theft Auto V/Tunnle.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Grand Theft Auto V/Tunnle.jpg" alt="Tunnel" />
    		</a>
		</div>
		<script src="javascript/blueimp-gallery.min.js"></script>
		<script>
			document.getElementById('links').onclick = function (event) {
    			event = event || window.event;
    			var target = event.target || event.srcElement,
         	link = target.src ? target.parentNode : target,
         	options = {index: link, event: event},
         	links = this.getElementsByTagName('a');
    			blueimp.Gallery(links, options);
			};
		</script>
	<?php
	?>
<?php
?>
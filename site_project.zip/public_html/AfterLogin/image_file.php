<?php
	//include "../setName.php";      
   //$setMyU = "user";
	$conn = mysqli_connect("mysql13.000webhost.com", "a8068632_root", "mCastro131", "a8068632_info") or die(mysqli_error());
		$user = $_COOKIE["user"];
		$sql = "SELECT ID, User_Image, User_Name FROM user WHERE User_Name = '$user'";
		
		$result = mysqli_query($conn, $sql) or die("<b>Error:</b> Problem on Retrieving Image BLOB<br/>" . mysql_error());
		$row = mysqli_fetch_array($result);

		echo $row["User_Image"];
	mysqli_close($conn);
?>
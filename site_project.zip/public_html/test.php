<?php
	include "connect.php";
?>
<?php
	include "open_html.php";
?>
	<?php
		include "htmlObody.php";
	?>
		<?php	
		if(count($_FILES) > 0) {
			if(is_uploaded_file($_FILES['image']['tmp_name'])) {
				mysql_connect("localhost", "root", "");
				$database_name = "testthings";
				mysql_select_db($database_name);
				$imgData =addslashes(file_get_contents($_FILES['image']['tmp_name']));
				$imageProperties = getimagesize($_FILES['image']['tmp_name']);
				$sql = "INSERT INTO testing(type ,TestFile) VALUES ('{$imageProperties['mime']}', '{$imgData}')";
				$current_id = mysql_query($sql) or die("<b>Error:</b> Problem on Image Insert<br/>" . mysql_error());
				}}
		?>
		<form enctype="multipart/form-data" method="post">
			<input type="file" name="image" />
			<input type="submit" name="submit" value="submit" />
		</form>
	<?php
		include "htmlCbody.php";
	?>
<?php
	include "close_html.php";
?>
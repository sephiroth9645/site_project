<?php   
   class Login
   {
       private $userName;
       private $userPassword;
       private $query;
       private $sqlLogin;
		 
		 const USER = "root";
		 const SERVER = "localhost";
		 const PASS = "";
		 const DB = "stealthgames";

       
       function __construct($name, $pass)
       {
           $this->userName = $name;
           $this->userPassword = $pass;

            

            $this->query = mysqli_connect(self::SERVER, self::USER, self::PASS, self::DB);
            if(mysqli_connect_errno())
            {
               echo "Failed to connect to MySQL: " . mysqli_connect_error();
            }
        }
        
        function setUserName($name)
        {
            $this->userName = $name;
         }
        
        function setUserPassword($pass)
        {
            $this->userPassword = $pass;
         }

         function getLoginInformation($name, $pass)
         {
             $this->userName = $name;
             $this->userPassword = $pass;

             $sqlLogin = mysqli_query($this->query, "SELECT * FROM create_user WHERE user_Name = '$this->userName' AND user_Password = md5('$this->userPassword')");
             if(mysqli_num_rows($sqlLogin) == 1)
             {
                 $row = mysqli_fetch_assoc($sqlLogin);
                 
                 setcookie("user", $row["user_Name"]);
                 header ("Location: ././AfterLogin/index.php");
              }
              else if(mysqli_num_rows($sqlLogin) == 0)
              {
                 echo "User name, and password incorrect please try again.";
              }
              else if(mysqli_num_rows($sqlLogin) > 1)
              {
                   echo "You are already logged in.";
              }
          }
    }
?>
<?php
    include "open_html.php";
?>
    <?php
        include "htmlObody.php";
    ?>
    		<p id="sample1" style="margin-top: -250px;">
    			Just remove the @package for the JAVA files. They should compile, and run. I don't take any responsibility for what other people
    			do with the code. It is open source, for most of my projects. The ones that are not, I have screen shots.
    		</p>
        <table id="samples">
            <tr>
                <th>
                    JAVA 
                </th>
                <th>
                    C#
                </th>
                <th>
                    C++
                </th>
            </tr>
            <tr>
                <td>
                    <a href="java.php">My Name</a>
                </td>
                <td>
                		 
                </td>
                <td>
                </td>
            </tr>
            <tr>
                <td>
                    <a href="input_name.php">Input Name</a>
                </td>
                <td>
                </td>
                <td>
                </td>
            </tr>
            <tr>
                <td>
                    <a href="grade_book.php">Grade Book</a>
                </td>
                <td>
                    
                </td>
                <td>
                </td>
            </tr>
            <tr>
                <td>
                   <a href="towers.php">Towers Of Hanoi</a>
                </td>
                <td>
                </td>
                <td>
                </td>          
            </tr>
            <tr>
                <td>
                   <a href="number_game.php">Guess the Number Game</a>
                </td>
                <td>
                </td>
                <td>
                </td>
            </tr>
            <tr>
               <td>
                   <a href="chart.php">Math Chart</a>
               </td>
               <td>
               </td>
               <td>
               </td>
            </tr>
            <tr>
                <th>
                    Android
                </th>
                <th>
                    Python
                </th>
                <th>
                    JQuery
                </th>
            </tr>
            <tr>
            	<td>
            	</td>
            	<td>
            		<a href="Projects/Python/degree.py">Degree</a>
            	</td>
            	<td>
            	</td>
            </tr>
            <tr>
            	<td>
            	</td>
            	<td>
            		<a href="Projects/Python/year_average.py">Average Wins</a>
            	</td>
            	<td>
            	</td>
            </tr>
            <tr>
            	<td>
            	</td>
            	<td>
            		<a href="Projects/Python/tipCalc.py">Tip Calculator</a>
            	</td>
            	<td>
            	</td>
            </tr>
            <tr>
            	<td>
            	</td>
            	<td>
            		<a href="Projects/Python/CompanyBonus.py">Company Bonus</a>
            	</td>
            	<td>
            	</td>
            </tr>
            <tr>
            	<td>
            	</td>
            	<td>
            		<a href="Projects/Python/Sales_Tax_App.py">Sales Tax</a>
            	</td>
            	<td>
            	</td>
            </tr>
        </table>
    <?php
        include "htmlCbody.php";
    ?>
<?php
    include "close_html.php";
?>

<?php
	include "open_html.php";
?>
	<?php
		include "htmlObody.php";
	?>
		<?php
			readfile("Projects/JAVA/TowersOfHanoi/src/towersofhanoi/TowersOfHanoi.java");
		?>
	<?php
		include "htmlCbody.php";
	?>
<?php
	include "close_html.php";
?>
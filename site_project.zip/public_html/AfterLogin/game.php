<?php
	include "open_html.php";
?>
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js">
	</script>
	
	<script type="text/javascript" >
		$(document).ready(function() {
			var player = image.attr('src', '');
		});
	</script>
	<?php
		include "htmlObody.php";
	?>
		
	<?php
		include "htmlCbody.php";
	?>
<?php
	include "close_html.php";
?>
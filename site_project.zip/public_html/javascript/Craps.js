// variables used to test the state of the game
         var WON = 0;
         var LOST = 1;
         var CONTINUE_ROLLING = 2;

         // other variables used in program
         var sumOfDice = 0; // sum of the dice
         var gameStatus = CONTINUE_ROLLING; // game not over yet

         // process one roll of the dice
         function play()
         {
            // get the status div on the page
            var statusDiv = document.getElementById( "status" );
            
            sumOfDice = rollDice();
   
            switch ( sumOfDice )
            {
              case 7: case 11:
              		 gameStatus = WON;
                   break;
             	case 2: case 12:
                   gameStatus = LOST;
                   break;
             	default: 
                   gameStatus = CONTINUE_ROLLING;
            } // end switch

            if ( gameStatus == CONTINUE_ROLLING )
               statusDiv.innerHTML = "Roll again";
            else 
            {
               if ( gameStatus == WON )
                  statusDiv.innerHTML = "Player wins. " +
                     "Click Roll Dice to play again.";   
               else 
                  statusDiv.innerHTML = "Player loses. " + 
                     "Click Roll Dice to play again.";
            } // end else
         } // end function play
   
         // roll the dice
         function rollDice()
         {
            var die1;
            var die2;
            var workSum;

            die1 = Math.floor( 1 + Math.random() * 6 );
            die2 = Math.floor( 1 + Math.random() * 6 );
            workSum = die1 + die2;

            document.getElementById( "dice1" ).value = die1; 
            document.getElementById( "dice2" ).value = die2;
            document.getElementById( "sum" ).value = workSum;

            return workSum;
         } // end function rollDice
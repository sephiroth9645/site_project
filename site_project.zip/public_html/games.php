<?php
	include "open_html.php";
?>
	<?php
		include "htmlObody.php";
	?>
	<table id="gameInfo">
		<?php
			include 'php_add_ons/stuff/connect.php';

			$games = "SELECT * FROM games Order By Publisher";
			
			$result = mysqli_query($con, $games);
			while($row = mysqli_fetch_assoc($result)) {
		?>
			
				<tr>
					<td>
						<?php 
							echo $row['Game_Name'];
						?>:
					</td>
					<td>
						<?php
							echo $row['Publisher'];
						?>
					</td>
					<td>
						<?php
							echo $row['Release_Date'];
						?>
					</td>
					<td>
						<?php
							echo $row['console'];
						?>
					</td>
				</tr>
		<?php
			}
		?>
		</table>
	<?php
		include "htmlCbody.php";
	?>
<?php
	include "close_html.php";
?>
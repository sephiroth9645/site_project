<?php	
	//variable to hold the value of cookie.
	$user = $_COOKIE["user"];
	$i = 1;

	//variable to hold the current logged in user.
	$matchID = mysqli_query($con, "SELECT create_user.user_ID, create_user.user_Name, create_user.user_Image, comment.user_ID, comment.comment_ID, comment.comment_User FROM create_user INNER JOIN comment ON create_user.user_ID = comment.user_ID");
?>
	<link rel="stylesheet" href="css/site.css" type="text/css" media="screen" />
	<link rel="stylesheet" href="css/style.css" type="text/css" />
<?php
	while($comment = mysqli_fetch_assoc($matchID)){
	//variable holding the user image that is logged in.
	$newQuery = mysqli_query($con, "SELECT user_ID, user_Name, user_Image FROM create_user WHERE user_Name = '$user'");
	//variable to hold the right image.
	$newRow = mysqli_fetch_assoc($newQuery);
?>
<div class="dropdown">
	<div class="content">
		<div id="Accord" class="accord">
				<button type="button" onclick="dropDown()" class="btnDrop">
					<span>
						<img src="data:image/jpeg;base64, <?php echo base64_encode($comment['user_Image']); ?>" style="width: 50px; height:50px" />
					</span>
					<span class="userName">
						<?php
							echo $comment["user_Name"];
						?>
					</span>
					<span class="userComment">
						<?php
							echo $comment["comment_User"];
						?>
					</span>
				</button>
				<div class="dropdown-content" style="display: none;">
						<img src="data:image/jpeg;base64, <?php echo base64_encode($newRow['user_Image']); ?>" style="width: 50px; height: 50px" />
					<div class="cookieUser">
						<?php
							echo $user;
						?>
					</div>
					<form enctype="metadata/form-data" method="post">
						<?php
							if(isset($_POST["replySubmit"])){
								$reply = $_POST["reply"];
								$checkReply = $_POST["checkReply"];
								$userID = $newRow["user_ID"];
								$commentID = $_POST["checkCommentID"];
							
								foreach($reply as $myReply){
									if($checkReply == $comment["user_ID"] && $comment["comment_ID"] == $commentID){
										echo $myReply.'<br />';
										$insert = mysqli_query($con, "INSERT INTO reply (user_ID, comment_ID, reply) VALUES ('$userID', '$commentID', '$myReply')");
									}
								}
							}else{
								//echo "Your comment could not be inserted at this time.";
							}
						?>
						<div class="textInput">
							<textarea name="reply[.com]" maxlength="255" ></textarea>
							<input type="hidden" name="checkReply" value="<?php echo $comment["user_ID"]; ?>" />
							<input type="hidden" name="checkCommentID" value="<?php echo $comment["comment_ID"] ?>" />
						</div>
						<div class="submitInput">
							<input type="submit" name="replySubmit" value="reply" />
						</div>
					</form>
					<?php
						$match = $comment["user_ID"];
						$query = mysqli_query($con, "SELECT create_user.user_ID, create_user.user_Name, create_user.user_Image, comment.comment_ID, reply.user_ID, reply.comment_ID, reply.reply FROM create_user INNER JOIN comment ON create_user.user_ID = comment.comment_ID INNER JOIN reply ON create_user.user_ID = reply.user_ID ORDER BY comment.comment_ID");
						while($row = mysqli_fetch_assoc($query)){
							if($row["comment_ID"] === $comment["comment_ID"]){
					?>
					<div>
						<img src="data:image/jpeg;base64, <?php echo base64_encode($row['user_Image']); ?> " style="width: 50px; height: 50px;" />
					</div>
					<div>
						<?php
							echo $row["user_Name"];
						?>
					</div>
					<div>
						<?php
							echo $row["reply"];
						?>
					</div>
					<?php
							}
						}
					?>
				</div>
		</div>
	</div>
</div>
<?php
	}
?>
	<script>
	function dropDown(){
		var testDrop = document.getElementsByClassName("dropdown-content");
		for(var i = 0; i < testDrop.length; i++){
			var newTest = testDrop[i];
			if(newTest.style.display === "none"){
				newTest.style.display = "block";
			}else{
				newTest.style.display = "none";
			}
		}
		/*for(let i = 0; i < testDrop.length; i++){
			alert(testDrop[i]);
		}*/
	}
	</script>

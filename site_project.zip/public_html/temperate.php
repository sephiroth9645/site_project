<?php
	include "open_html.php";
?>
	<?php
		include "htmlObody.php";
	?>
		<div>This conversion calculator assumes the temperature being entered is Fahrenheit.</div>
		<input type="text" id="currentTemp"/>
		<br />
		Fahrenheit:&nbsp;<div><input type="text" readonly="true" value="0" id="fahrenheit" style="border-style: none; background-color: #f5f5f5;" /></div>
		<br />
		<div><input type="text" readonly="true" value="0" style="border-style: none; background-color: #f5f5f5;" id="negFahrenheit" /></div>
		<br />
		Celcius:&nbsp;<div><input type="text" value="0" readonly="true" style="border-style: none; background-color: #f5f5f5;" id="celcius"/></div>
		<br />
		<div><input type="text" readonly="true" value="0" style="border-style: none; background-color: #f5f5f5;" id="negCel" /></div>
		<br />
		Kelvin:&nbsp;<div><input type="text" readonly="true" value="0" style="border-style: none; background-color: #f5f5f5;" id="kelvin" /></div>
		<br />
		<script type="text/javascript" >			
			function init(){
				var cT = document.getElementById("currentTemp").value;
				fahren(cT);
				celci(cT);
				kelv(cT);
			}
			
			function fahren(cT){
				document.getElementById("fahrenheit").value = cT;
				document.getElementById("negFahrenheit").value = -cT;
			}
			
			function celci(cT){
				document.getElementById("celcius").value = (cT - 32) * (5 / 9);				
				document.getElementById("negCel").value = -(cT - 32) * (5 / 9);
			}
			
			function kelv(cT){
				document.getElementById("kelvin").value = (459.67 + cT) * (5 / 9);
			}
		</script>
		<button id="btnConvert" onclick="init()" >convert</button>
	<?php
		include "htmlCbody.php";
	?>
<?php
	include "close_html.php"
?>
<?php	
	if(count($_FILES) > 0) {
		if(is_uploaded_file($_FILES['image']['tmp_name'])) {
			
			include 'connect.php';
			
			$imgData = addslashes(file_get_contents($_FILES['image']['tmp_name']));
			$imageProperties = getimagesize($_FILES['image']['tmp_name']);
			$sql = "INSERT INTO game_image(type , Game_Image) VALUES ('{$imageProperties['mime']}', '{$imgData}')";
			$current_id = mysqli_query($con, $sql);
	}
}
?>
    <body>
        <canvas id="hdCanvas">
            Your browswer does not support canvas.
        </canvas>
			<?php
   			include "navigation.php";
			?>
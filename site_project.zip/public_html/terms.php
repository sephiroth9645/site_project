<?php
	include "open_html.php";
?>
	<?php
		include "htmlObody.php";
	?>
		<p>
			&nbsp;&nbsp;&nbsp;&nbsp;By checking the box you under stand that all code samples are open source. You also agree that any modifications that you do<br />
			are not my property, but yours, and that I will not be held responsible for any of your actions.  I have code that is not source, and will only be displayed <br />
			as screen shots. 
		</p>
	<?php
		include "htmlCbody.php";
	?>
<?php
	include "close_html.php";
?>
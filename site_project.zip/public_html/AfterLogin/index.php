<?php
	include "open_html.php";
?>
	<?php
		include "htmlObody.php";
	?>
		<form>
      <p>
         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hello my name is Michael. I'm wanting a career in Software Development, though most of my back ground is working on desktops, and Microsoft servers. Started working on building my own computers at the age of 17, and found it more interesting than trying to design logos. Truly didn't get into the IT field until 2009. That is when taking a JAVA class: really found that was a better choice.
      </p>
		<p style="">
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Finally graduated from ITT TECHNICAL Institute in 2012: ASSOCIATE OF APPLIED SCIENCE DEGREE. Having several Honors, final GPA was 3.45. Overall question did this person that wrote this learn anything? Learning how to design web sites using HTML, CSS, and javascript: boosted my knowledge. PHP, ASP.Net VB, JAVA, and PYTHON showed how using classes, methods/functions could be used to make coding more readable, and functional.
After graduation: sought full time employment. Skipping ahead a year: worked at Discover Financial Services. Hired on as a Operator 1 working the night shift. Can't go into a lot of detail, other than preparing credit cards. Left their for a web development position at VitalBGS.
VitalBGS was a contract to hire position. Worked with several different CMS's WordPress, OpenCart, X-Cart, and a little of Magento. Left there on good terms: working at the bishops warehouse for a short while.
		</p>
		<p style="">
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;At the bishops warehouse stocked shelves taking carts from the back, and placing the items from the carts to the correct shelves. After working for two months I was asked to work in the large area. That entailed furniture, workout machines, and electronics. While in that area when asked for an order: needed to write a ticket, give a copy to the customer and told them that they had half an hour to pick it up. We could hold items for a maximum of 24 hours after being bought. When working the closing shift, swept the floor, and pick up any items left on the floor, and put them back in their appropriate spots. It was fun working their for the most part. This was a 1 year contract, found work at an IT place called Ray & Rae Enterprises.
While at Ray & Ray Enterprises managed 20 desktops, 16 SNOM 710 – 720 VoIP phones, 50 thin clients, 10 Microsoft Multipoint servers, Active Directory, Micorsoft Lync, Office 365, and Exchange. On one particular day: someone had downloaded malicious software known as Trovi. As soon as I got in, I notified my boss, and was told to disconnect the infected desktops until he got back. My boss while working their was also a airline pilot. More than half the desktops were already infected, I disconnected the network cables, and researched how to remove the virus without having to re-image the desktops. Found a web site that went through step by step on how to remove the viirus: when not having an antivirus. We had a fire wall, just didn't have antivirus software until after this incident. Before connecting the network cables to the desktops, went to the server room found where the software had been downloaded, it was on our exchange server. Deleted the downloaded files, and removed the virus from the server. After accomplishing that: installed Comodo Antivirus on all the desktops as well as PC cleaner for maleware removal. 
		</p>
		</form>
	<?php
		include "htmlCbody.php";
	?>
<?php
	include "close_html.php";
?>
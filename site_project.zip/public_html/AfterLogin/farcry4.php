<?php
	include "open_html.php";
?>
	<?php
		include "htmlObody.php";
	?>
			   <link rel="stylesheet" href="css/blueimp-gallery.min.css">
		<!-- The Gallery as lightbox dialog, should be a child element of the document body -->
		<div id="blueimp-gallery" class="blueimp-gallery">
    		<div class="slides"></div>
    		<h3 class="title"></h3>
    		<a class="prev">‹</a>
    		<a class="next">›</a>
    		<a class="close">×</a>
    		<a class="play-pause"></a>
    		<ol class="indicator"></ol>
		</div>
		<div id="links" style="margin-top: 40px; margin-left: 350px;">
    		<a href="images/PS4/SHARE/Screenshots/Far Cry 4/Flying.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Far Cry 4/Flying.jpg" alt="Flying" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Far Cry 4/Scenery.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Far Cry 4/Scenery.jpg" alt="Scenery" />
    		</a>
		</div>
		<script src="javascript/blueimp-gallery.min.js"></script>
		<script>
			document.getElementById('links').onclick = function (event) {
    			event = event || window.event;
    			var target = event.target || event.srcElement,
         	link = target.src ? target.parentNode : target,
         	options = {index: link, event: event},
         	links = this.getElementsByTagName('a');
    			blueimp.Gallery(links, options);
			};
		</script>
	<?php
		include "htmlCbody.php";
	?>
<?php
	include "close_html.php";
?>
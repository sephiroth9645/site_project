<?php
	include "open_html.php";
?>
	<?php
		include "htmlObody.php";
	?>
	   <link rel="stylesheet" href="css/blueimp-gallery.min.css">
		<!-- The Gallery as lightbox dialog, should be a child element of the document body -->
		<div id="blueimp-gallery" class="blueimp-gallery">
    		<div class="slides"></div>
    		<h3 class="title"></h3>
    		<a class="prev">‹</a>
    		<a class="next">›</a>
    		<a class="close">×</a>
    		<a class="play-pause"></a>
    		<ol class="indicator"></ol>
		</div>
		<div id="links" style="margin-top: 40px; margin-left: 100px;">
    		<a href="images/PS4/SHARE/Screenshots/Destiny/Cabal_1.jpg" title="Cabal 1">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/Cabal_1.jpg" alt="Cabal" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/Cabal_2.jpg" title="Cabal 2">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/Cabal_2.jpg" alt="Cabal 2" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/Cabal_3.jpg" title="Cabal 3">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/Cabal_3.jpg" alt="Cabal 3" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/Cabal_4.jpg" title="Cabal 4">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/Cabal_4.jpg" alt="Cabal 4" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/Crota.jpg" title="Crota">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/Crota.jpg" alt="Crota" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/Daughters.jpg" title="Daughters">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/Daughters.jpg" alt="Daughters" />
    		</a>

			<a href="images/PS4/SHARE/Screenshots/Destiny/Dreadnaught.jpg" title="Dreadnaught">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/Dreadnaught.jpg" alt="Dreadnaught" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/FirstBlood.jpg" title="First Blood">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/FirstBlood.jpg" alt="First Blood" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/Force.jpg" title="Force">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/Force.jpg" alt="Force" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/Gjallahorn.jpg" title="Gjallarhorn">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/Gjallahorn.jpg" alt="Gjallahorn" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/Holloween.jpg" title="Holloween">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/Holloween.jpg" alt="Holloween" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/HungerPangs.jpg" title="Hunger Pangs">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/HungerPangs.jpg" alt="Hunger Pangs" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/Hunter.jpg" title="Hunter">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/Hunter.jpg" alt="Hunter" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/HunterKiller.jpg" title="Hunter Killer">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/HunterKiller.jpg" alt="Hunter Killer" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/Minotaur.jpg" title="Vex Minotaur">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/Minotaur.jpg" alt="Vex Minotaur" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/NIghtCourt.jpg" title="NIght Court">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/NIghtCourt.jpg" alt="NIght Court" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/NightStalker.jpg" title="Night Stalker">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/NightStalker.jpg" alt="Night Stalker" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/Oryx.jpg" title="Oryx">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/Oryx.jpg" alt="Oryx" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/Platforms.jpg" title="Platforms">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/Platforms.jpg" alt="Platforms" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/Players.jpg" title="Players">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/Players.jpg" alt="Players" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/PokingFun.jpg" title="Poking Fun">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/PokingFun.jpg" alt="Poking Fun" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/Sanctuary.jpg" title="Sanctuary">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/Sanctuary.jpg" alt="Sanctuary" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/Scheming.jpg" title="Schemeing">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/Scheming.jpg" alt="Schemeing" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/ScoreBoard.jpg" title="Score Board">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/ScoreBoard.jpg" alt="Score Board" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/SecondWind.jpg" title="Second Wind">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/SecondWind.jpg" alt="Second Win" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/SightSeeing.jpg" title="Sight Seeing">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/SightSeeing.jpg" alt="Sight Seeing" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/SRL.jpg" title="SRL">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/SRL.jpg" alt="SRL" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/StormCaller.jpg" title="Storm Caller">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/StormCaller.jpg" alt="Storm Caller" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/Strike.jpg" title="Strike">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/Strike.jpg" alt="Strike" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/TakenKing.jpg" title="Taken King">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/TakenKing.jpg" alt="Taken King" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/Titan.jpg" title="Titan">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/Titan.jpg" alt="Titan" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/Warlock.jpg" title="Warlock">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/Warlock.jpg" alt="Warlock" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Destiny/WolfProblems.jpg" title="Wolf Problems">
    			<img width="300px" src="images/PS4/SHARE/Screenshots/Destiny/WolfProblems.jpg" alt="Wolf Problems" />
    		</a>
		</div>
		<script src="javascript/blueimp-gallery.min.js"></script>
		<script>
			document.getElementById('links').onclick = function (event) {
    			event = event || window.event;
    			var target = event.target || event.srcElement,
         	link = target.src ? target.parentNode : target,
         	options = {index: link, event: event},
         	links = this.getElementsByTagName('a');
    			blueimp.Gallery(links, options);
			};
		</script>
	<?php
		include "htmlCbody.php";
	?>
<?php
	include "close_html.php";
?>
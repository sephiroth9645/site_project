<?php
if(isset($_POST['submit']))
{    
	$user = "root";
	$pass = "";
	$server = "localhost";
	$db = "testthings";
	
	$query = mysqli_connect($server, $user, $pass, $db);
     
 /**$file = rand(1000,100000)."-".$_FILES['image']['name'];
 $file_loc = $_FILES['image']['tmp_name'];
 $file_size = $_FILES['image']['size'];
 $file_type = $_FILES['image']['type'];
 */
 $file = file($_POST['image']);
 $folder="images/PS4/SHARE/Screenshots/Just Cause 3/";
 
 move_uploaded_file($folder.$file);
 $sql = mysqli_query($query, "INSERT INTO Testing(TestFile) VALUES('$file')");
}
?>
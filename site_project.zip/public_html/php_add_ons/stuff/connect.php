<?php
	
	$user = "root";
	$pass = "";
	$server = "localhost";
	$DB = "stealthgames";
	
	$con = mysqli_connect($server, $user, $pass, $DB);
	
	if(mysqli_connect_errno())
	{
		die (mysqli_connect_errno());
	}
?>
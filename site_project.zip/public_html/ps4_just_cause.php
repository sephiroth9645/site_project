<?php
	include 'open_html.php';
?>
	<?php
		include 'htmlObody.php';
	?>
		<?php
			include 'php_add_ons/stuff/insert_images.php';
		?>
		<form enctype="multipart/form-data" method="post">
			<input type="file" name="image" />
			<input type="submit" name="submit" value="submit" />
		</form>
		<?php
		?>
	<?php
		include 'htmlCbody.php';
	?>
<?php
	include 'close_html.php';
?>
<?php
			$conn = mysql_connect("mysql13.000webhost.com", "a8068632_root", "mCastro131");
			mysql_select_db("a8068632_info");
			$sql = "SELECT ID FROM game_image ORDER BY ID DESC"; 
			$result = mysql_query($sql);
?>
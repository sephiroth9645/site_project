function rollStats(){
	var str = document.getElementById("str");
	var con = document.getElementById("con");
	var dex = document.getElementById("dex");
	var intele = document.getElementById("intele");
	var wis = document.getElementById("wis");
	var cha = document.getElementById("cha");
	var luk = document.getElementById("luk");
	var total = document.getElementById("total");
	
	var randStr = Math.floor((Math.random() * 20) + 1);
	var randCon = Math.floor((Math.random() * 20) + 1);
	var randDex = Math.floor((Math.random() * 20) + 1);
	var randIntele = Math.floor((Math.random() * 20) + 1);
	var randWis = Math.floor((Math.random() * 20) + 1);
	var randCha = Math.floor((Math.random() * 20) + 1);
	var randLuk = Math.floor((Math.random() * 20) + 1);

	str.value = randStr;
	con.value = randCon;
	dex.value = randDex;
	intele.value = randIntele;
	wis.value = randWis ;
	cha.value = randCha;
	luk.value = randLuk;
	
	total.value = randStr + randCon + randDex + randIntele + randWis + randCha + randLuk;

	if(str.value <= 5){
		str.style.color = "#696969";
	}else if(str.value >= 5 && str.value <= 10){
		str.style.color = "#FF0000";
	}else if(str.value >= 10 && str.value <= 15){
		str.style.color = "#007887";
	}else if(str.value >= 15 && str.value <= 20){
		str.style.color = "#a17f1a";
	}

	if(con.value <= 5){
		con.style.color = "#696969";
	}else if(con.value >= 5 && con.value <= 10){
		con.style.color = "#FF0000";
	}else if(con.value >= 10 && con.value <= 15){
		con.style.color = "#007887";
	}else if(con.value >= 15 && con.value <= 20){
		con.style.color = "#a17f1a";
	}

	if(dex.value <= 5){
		dex.style.color = "#696969";
	}else if(dex.value >= 5 && dex.value <= 10){
		dex.style.color = "#FF0000";
	}else if(dex.value >= 10 && dex.vamlue <= 15){
		dex.style.color = "#007887";
	}else if(dex.value >= 15 && dex.value <= 20){
		dex.style.color = "#a17f1a";
	}

	if(intele.value <= 5){
		intele.style.color = "#696969";
	}else if(intele.value >= 5 && intele.value <= 10){
		intele.style.color = "#FF0000";
	}else if(intele.value >= 10 && intele.value <= 15){
		intele.style.color = "#007887";
	}else if(intele.value >= 15 && intele.value <= 20){
		intele.style.color = "#a17f1a";
	}

	if(wis.value <= 5){
		wis.style.color = "#696969";
	}else if(wis.value >= 5 && wis.value <= 10){
		wis.style.color = "#FF0000";
	}else if(wis.value >= 10 && wis.value <= 15){
		wis.style.color = "#007887";
	}else if(wis.value >= 15 && wis.value <= 20){
		wis.style.color = "#a17f1a";
	}

	if(cha.value <= 5){
		cha.style.color = "#696969";
	}else if(cha.value >= 5 && cha.value <= 10){
		cha.style.color = "#FF0000";
	}else if(cha.value >= 10 && cha.value <= 15){
		cha.style.color = "#007887";
	}else if(cha.value >= 15 && cha.value <= 20){
		cha.style.color = "#a17f1a";
	}

	if(luk.value <= 5){
		luk.style.color = "#696969";
	}else if(luk.value >= 5 && luk.value <= 10){
		luk.style.color = "#FF0000";
	}else if(luk.value >= 10 && luk.value <= 15){
		luk.style.color = "#007887";
	}else if(luk.value >= 15 && luk.value <= 20){
		luk.style.color = "#a17f1a";
	}

	if(total.value <= 40){
		luk.style.color = "#696969";
	}else if(luk.value >= 40 && luk.value <= 60){
		luk.style.color = "#FF0000";
	}else if(luk.value >= 60 && luk.value <= 80){
		luk.style.color = "#00009f";
	}else if(luk.value >= 80 && luk.value <= 100){
		luk.style.color = "#007887";
	}else if(luk.value >= 100 && luk.value <= 120){
		luk.style.color = "#fe5000";
	}else if(luk.value >= 120 && luk.value <= 140){
		luk.style.color = "#a17f1a";
	}
}

function randomName(){
	var name = document.getElementById("characterName");

	var nameArray = ["Durpzey", "Woozy", "Xialm", "Chloric", "Ralfo", "Tidbit", "Qunchi", "Bitchy Mc Bitch Pants", "Lizard Eating Lady"];

	var rndName = nameArray[Math.floor(Math.random() * nameArray.length)];

	name.value = rndName;
}

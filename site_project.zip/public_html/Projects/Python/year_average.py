yearOne = input('How many games won in year 1? ')
yearTwo = input('How many games won in year 2? ')
yearThree = input('How many games won in year 3? ')
yearFour = input('How many games won in year 4? ')
yearFive = input('How many games won in year 5? ')

average = (yearOne + yearTwo + yearThree + yearFour + yearFive) / 5

print 'The average for the last five years is: ', average

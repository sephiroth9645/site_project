<?php
	
	$user = "a8068632_root";
	$pass = "mCastro131";
	$server = "localhost";
	$DB = "a8068632_info";

	$con = mysqli_connect($server, $user, $pass, $DB);
	
	if(mysqli_connect_errno())
	{
		die (mysqli_connect_errno());
	}
?>
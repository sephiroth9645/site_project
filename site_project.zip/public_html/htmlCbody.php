<?php
?>
      <footer>
      	Michael Castro &copy; Copyright 2016 all rights reserved.
      </footer>
      <script src="javascript/particles.js" type="text/javascript">
      </script>
      </div>
   </body>
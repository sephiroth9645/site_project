<?php
	include "open_html.php";
?>
	<?php
		include "htmlObody.php";
	?>
		<form enctype="multipart/form-data" method="post">
			<div>
				<table>
					<?php
						$user = $_COOKIE["user"];
						$query = mysqli_query($con, "SELECT * FROM friend_request INNER JOIN user ON user.ID = User_ID WHERE user.User_Name <> '$user'");
					
						while($row = mysqli_fetch_assoc($query)){
					?>
						<tr>
							<td>
								<img src="data:image/jpeg;base64, <?php echo base64_encode($row['User_Image']); ?>" style="width: 50px; height:50px" />
							</td>
							<td>
								<?php echo $row["User_Name"]; ?>
							</td>
							<td>
								<?php echo $row["Message"]; ?>
							</td>
							<td>
								<input type="submit" name="accept" value="accept" />
							</td>
							<td>
								<input type="submit" name="deny" value="deny" />
							</td>
						</tr>
					<?php
						}
					?>
				</table>
			</div>
		</form>
	<?php
		include "htmlCbody.php";
	?>
<?php
	include "close_html.php";
?>
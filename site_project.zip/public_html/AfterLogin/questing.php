<?php
	include "open_html.php";
?>
	<?php
		include "htmlObody.php";
	?>

	<?php
		include "php_classes/Game.class.php";

		if(isset($_POST["start"])){
			$user = $_COOKIE["user"];
			$name = $_POST["characterName"];
			$chrClass = $_POST["chrClass"];
			$usrChar = $_POST["character"];
			$str = $_POST["str"];
			$con = $_POST["con"];
			$dex = $_POST["dex"];
			$intele = $_POST["intele"];
			$wis = $_POST["wis"];
			$cha = $_POST["cha"];
			$luk = $_POST["luk"];
			$lvl = 1;
			$exp = 0;
			$hp = 100;
			$mp = 100;

			$testData = "$user" . PHP_EOL. "$name" . PHP_EOL . "$chrClass" . PHP_EOL . "$usrChar" . PHP_EOL . "$str" . PHP_EOL . "$con" . PHP_EOL. "$dex" . PHP_EOL . "$intele" . PHP_EOL . "$wis" . PHP_EOL . "$cha" . PHP_EOL . "$luk" . PHP_EOL . "$lvl" . PHP_EOL . "$exp" . PHP_EOL . "$hp" . PHP_EOL . "$mp";
			
			$createTestFile = fopen("gameSaves/".$user.".txt", "c") or die("Oops I did something wrong");

			fwrite($createTestFile, $testData);

			fclose($createTestFile);
		}
	?>

	<script type="text/javascript" src="javascript/questing.js">
	</script>
	<form enctype="multipart/form-data" method="post">
	<div>	
		<div id="setName">
			Name: <input type="text" name="characterName" id="characterName" />&nbsp;<button type="button" id="randomCharacterName" onclick="randomName()">?</button>
		</div>
		<br />
		<div id="setSpecies">
			<input type="radio" id="character" name="character" value="human"/><label for="chr1" >Human</label>
			<br />
			<input type="radio" id="character" name="character" value="Half-Human"/><label for="chr2" >Half-Human</label>
			<br />
			<input type="radio" id="character" name="character" value="Halfling"/><label for="chr3" >HalfLing</label>
			<br />
			<input type="radio" id="character" name="character" value="Smallfoot"/><label for="chr4" >Smallfoot</label>
			<br />
			<input type="radio" id="character" name="character" value="Bigfoot"/><label for="chr5" >Bigfoot</label>
			<br />
			<input type="radio" id="character" name="character" value="Light Elf"/><label for="chr6" >Light Elf</label>
			<br />
			<input type="radio" id="character" name="character" value="Brush Elf"/><label for="chr7" >Brush Elf</label>
			<br />
			<input type="radio" id="character" name="character" value="Forest Elf"/><label for="chr8" >Forest Elf</label>
			<br />
			<input type="radio" id="character" name="character" value="Swamp Elf"/><label for="chr9" >Swamp Elf</label>
			<br />
			<input type="radio" id="character" name="character" value="Dark Elf"/><label for="chr10" >Dark Elf</label>
			<br />
			<input type="radio" id="character" name="character" value="Dread Elf"/><label for="chr11" >Dread Elf</label>
			<br />
			<input type="radio" id="character" name="character" value="Death Elf"/><label for="chr12" >Death Elf</label>
			<br />
			<input type="radio" id="character" name="character" value="Zombie Elf>"/><label for="chr13" >Zombie Elf</label>
			<br />
			<input type="radio" id="character" name="character" value="Death Dwarf"/><label for="chr14" >Death Dwarf</label>
			<br />
			<input type="radio" id="character" name="character" value="Grey Dwarf"/><label for="chr15" >Grey Dwarf</label>
			<br />
			<input type="radio" id="character" name="character" value="Zombie Dwarf"/><label for="chr16" >Zombie Dwarf</label>
			<br />
			<input type="radio" id="character" name="character" value="Lich King"/><label for="chr17" >Lich King</label>
			<br />
			<input type="radio" id="character" name="character" value="Dwarf"/><label for="chr18" >Dwarf</label>
			<br />
			<input type="radio" id="character" name="character" value="Red Dwarf"/><label for="chr20" >Red Dwarf</label>
			<br />
			<input type="radio" id="character" name="character" value="Draconis"/><label for="chr21" >Draconis</label>
			<br />
			<input type="radio" id="character" name="character" value="Fish Man"/><label for="chr22" >Fish Man</label>
			<br />
			<input type="radio" id="character" name="character" value="Vampyer"/><label for="chr23" >Vampyer</label>
			<br />
			<input type="radio" id="character" name="character" value="Bird Name"/><label for="chr24" >Bird Name</label>
			<br />
			<input type="radio" id="character" name="character" value="Minitaur"/><label for="chr25" >Minitaur</label>
			<br />
			<input type="radio" id="character" name="character" value="Alien"/><label for="chr26" >Alien</label>
			<br />
			<input type="radio" id="character" name="character" value="Cyborg"/><label for="chr27" >Cyborg</label>
		</div>
		<div id="setClass">
			<input type="radio" id="chrClass" name="chrClass" value="Necromancer"/><label for="cls1" >Necromancer</label>
			<br />
			<input type="radio" id="chrClass" name="chrClass" value="Summoner"/><label for="cls2" >Summoner</label>
			<br />
			<input type="radio" id="chrClass" name="chrClass" value="Blood Mage"/><label for="cls3" >Blood Mage</label>
			<br />
			<input type="radio" id="chrClass" name="chrClass" value="Experimenter"/><label for="cls3" >Experimenter</label>
			<br />
			<input type="radio" id="chrClass" name="chrClass" value="Mage"/><label for="cls3" >Mage</label>
			<br />
			<input type="radio" id="chrClass" name="chrClass" value="Saint"/><label for="cls4" >Saint</label>
			<br />
			<input type="radio" id="chrClass" name="chrClass" value="Enchanter"/><label for="cls5" >Enchanter</label>
			<br />
			<input type="radio" id="chrClass" name="chrClass" value=Barbarion"/><label for="cls6" >Barbarion</label>
			<br />
			<input type="radio" id="chrClass" name="chrClass" value="Warrior"/><label for="cls7" >Warrior</label>
			<br />
			<input type="radio" id="chrClass" name="chrClass" value="Scholar"/><label for="cls8" >Scholar</label>
			<br />
			<input type="radio" id="chrClass" name="chrClass" value"kiMaster"/><label for="cls9" >Ki Master</label>
			<br />
			<input type="radio" id="chrClass" name="chrClass" value="Techknowlogist"/><label for="cls10" >Techknowlogist</label>
			<br />
			<input type="radio" id="chrClass" name="chrClass" value="Mechanic"/><label for="cls11" >Mechanic</label>
			<br />
			<input type="radio" id="chrClass" name="chrClass" value="Grenader"/><label for="cls12" >Grenader</label>
			<br />
			<input type="radio" id="chrClass" name="chrClass" value="Alchemist"/><label for="cls13" >Alchemist</label>
			<br />
			<input type="radio" id="chrClass" name="chrClass" value="Infectious"/><label for="cls14" >Infectious</label>
			<br />
			<input type="radio" id="chrClass" name="chrClass" value="Death Mage"/><label for="cls15" >Death Mage</label>
			<br />
			<input type="radio" id="chrClass" name="chrClass" value="Tickle Telekinesis"/><label for="cls16">Tickle Telekinesis</label>
			<br />
			<input type="radio" id="chrClass" name="chrClass" value="Rune Mastert"/><label for="cls17">Rune Master</label>
			<br />
			<input type="radio" id="chrClass" name="chrClass" value="Demon Slayer"/><label for="cls18">Demon Slayer</label>
			<br />
			<input type="radio" id="chrClass" name="chrClass" value="Thief"/><label for="cls19">Thief</label>
			<br />
			<input type="radio" id="chrClass" name="chrClass" value="Crazy Assassin"/><label for="cls20">Crazy Assassin</label>
			<br />
		</div>
		<div id="setAttributes">
			<label >Str:</label>&nbsp;<input readonly="readonly" type="text" id="str" name="str" size="1" style="margin-left: 14px; border: none; background-color: #f5f5f5;"/>
			<br />
			<label >Con:</label>&nbsp;<input readonly="readonly" type="text" id="con" name="con" size="1" style="margin-left: 5px; border: none; background-color: #f5f5f5;"/>
			<br />
			<label >Dex:</label>&nbsp;<input readonly="readonly" type="text" id="dex" name="dex" size="1" style="margin-left: 6px; border: none; background-color: #f5f5f5;"/>
			<br />
			<label >Int:</label>&nbsp;<input readonly="readonly" type="text" id="intele" name="intele" size="1" style="margin-left: 16px; border: none; background-color: #f5f5f5;"/>
			<br />
			<label >Wis:</label>&nbsp;<input readonly="readonly" type="text" id="wis" name="wis" size="1" style="margin-left: 7px; border: none; background-color: #f5f5f5;"/>
			<br />
			<label >Cha:</label>&nbsp;<input readonly="readonly" type="text" id="cha" name="cha" size="1" style="margin-left: 5px; border: none; background-color: #f5f5f5;"/>
			<br />
			<label >Luck:</label>&nbsp;<input readonly="readonly" type="text" id="luk" name="luk" size="1" style="margin-left: 0px; border: none; background-color: #f5f5f5;"/>
			<br />
			<label>Total</label>&nbsp;<input readonly="readonly" type="text" id="total" name="total" size="1" style="border: none; background-color: #f5f5f5;" />
			<br />
			<br />
			<br />
			<br />
			<button type="button" id="roll" name="roll" onclick="rollStats()">Roll</button>
		</div>
		<br />
		<br />
		<br />
		<br />
		<br />
		<br />
		<br />
		<div id="startGame">
		<button type="submit" id="start" name="start" >Start!</button>
		</div>
	</div>
	</form>
	<?php
		include "htmlCbody.php";
	?>
<?php
	include "close_html.php";
?>

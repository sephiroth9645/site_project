<?php
	include "PHP_Classes/more_stuff/booka.class.php";
?>
	<?php
		include "open_html.php";
	?>
		<?php
			include "htmlObody.php";
		?>
		<?php
			if(isset($_POST['submit']))
			{
					$bookName = $_POST['bookName'];
					$bookAuthor = $_POST['bookAuthor'];
					$publish = $_POST['publishDate'];
					
					$insertBook = new Books($bookName, $bookAuthor, $publish);
					if(isset($bookName) && isset($bookAuthor) && isset($publish))
					{
						$insertBook->getInsertBook($bookName, $bookAuthor, $publish);
					}
			}
		?>
			<form method="post">
				<table id="resume">
					<tr>
						<td>
							Book Name:
						</td>
					</tr>
					<tr>
						<td>
							<input type="text" name="bookName" />
						</td>
					</tr>
					<tr>
						<td>
							Author Name:
						</td>
					</tr>
					<tr>
						<td>
							<input type="text" name="bookAuthor" />
						</td>
					</tr>
					<tr>
						<td>
							Publish Date:
						</td>
					</tr>
					<tr>
						<td>
							<input type="date" name="publishDate" />
						</td>
					</tr>
					<tr>
						<td>
							<input type="file" name="file" />
						</td>
					</tr>
					<tr>
						<td>
							<input type="submit" name="submit" value="submit" />
						</td>
					</tr>
				</table>			
			</form>
		<?php
			include "htmlCbody.php";
		?>
	<?php
		include "close_html.php";
	?>
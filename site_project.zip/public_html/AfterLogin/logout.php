<?php
// logout.php
// you must start session before destroying it
session_start();
session_unset();
session_destroy();
//}
//echo "You have been successfully logged out.
///to unet the cookie set it to a pas t time
setcookie ("user", "", time() - 3600);
echo "You have logged out.";
	echo "<a href=\"../default.php\">home</a>"
?>


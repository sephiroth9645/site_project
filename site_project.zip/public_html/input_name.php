<?php
	include "open_html.php";
?>
	<?php
		include "htmlObody.php";
	?>
		<div style="margin-left: 100px; margin-top: -250px;">
			<?php
				readfile("Projects/JAVA/InputName/src/inputname/InputName.java");
			?>
		</div>
	<?php
		include "htmlCbody.php";
	?>
<?php
	include "close_html.php";
?>
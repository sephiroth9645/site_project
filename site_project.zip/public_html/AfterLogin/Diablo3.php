<?php
	include "open_html.php";
?>
	<?php
		include "htmlObody.php";
	?>
			   <link rel="stylesheet" href="css/blueimp-gallery.min.css">
		<!-- The Gallery as lightbox dialog, should be a child element of the document body -->
		<div id="blueimp-gallery" class="blueimp-gallery">
    		<div class="slides"></div>
    		<h3 class="title"></h3>
    		<a class="prev">‹</a>
    		<a class="next">›</a>
    		<a class="close">×</a>
    		<a class="play-pause"></a>
    		<ol class="indicator"></ol>
		</div>
		<div id="links" style="margin-top: 40px; margin-left: 90px;">
    		<a href="images/PS4/SHARE/Screenshots/DiabloIII/Cain.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/DiabloIII/Cain.jpg" alt="Cain" />
    		</a>
			<a href="images/PS4/SHARE/Screenshots/DiabloIII/Cow.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/DiabloIII/Cow.jpg" alt="Band" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/DiabloIII/Death1.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/DiabloIII/Death2.jpg" alt="Death 2" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/DiabloIII/Death3.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/DiabloIII/Death3.jpg" alt="Death 3" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/DiabloIII/Death4.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/DiabloIII/Death4.jpg" alt="Death 4" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/DiabloIII/Death5.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/DiabloIII/Death5.jpg" alt="Death 5" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/DiabloIII/Death6.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/DiabloIII/Death6.jpg" alt="Death 6" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/DiabloIII/Death7.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/DiabloIII/Death7.jpg" alt="Death 7" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/DiabloIII/Derby.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/DiabloIII/Derby.jpg" alt="Derby" />
    		</a>
			<a href="images/PS4/SHARE/Screenshots/DiabloIII/Greed.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/DiabloIII/Greed.jpg" alt="Greed" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/DiabloIII/Highlands.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/DiabloIII/Highlands.jpg" alt="Highlands" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/DiabloIII/New.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/DiabloIII/New.jpg" alt="New" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/DiabloIII/Reaper.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/DiabloIII/Reaper.jpg" alt="Reaper" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/DiabloIII/Rift.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/DiabloIII/Rift.jpg" alt="Rift" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/DiabloIII/Selling.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/DiabloIII/Selling.jpg" alt="Selling" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/DiabloIII/Soulstone.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/DiabloIII/Soulstone.jpg" alt="Soulstone" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/DiabloIII/Team.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/DiabloIII/Team.jpg" alt="Team" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/DiabloIII/Witch.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/DiabloIII/Witch.jpg" alt="Witch" />
    		</a>
		</div>
		<script src="javascript/blueimp-gallery.min.js"></script>
		<script>
			document.getElementById('links').onclick = function (event) {
    			event = event || window.event;
    			var target = event.target || event.srcElement,
         	link = target.src ? target.parentNode : target,
         	options = {index: link, event: event},
         	links = this.getElementsByTagName('a');
    			blueimp.Gallery(links, options);
			};
		</script>
	<?php
		include "htmlCbody.php";
	?>
<?php
	include "close_html.php";
?>
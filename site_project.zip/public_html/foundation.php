<?php
	include "open_html.php";
?>
	<?php
		include "htmlObody.php";
	?>
	   <link rel="stylesheet" href="css/blueimp-gallery.min.css">
		<!-- The Gallery as lightbox dialog, should be a child element of the document body -->
		<div id="blueimp-gallery" class="blueimp-gallery">
    		<div class="slides"></div>
    		<h3 class="title"></h3>
    		<a class="prev">‹</a>
    		<a class="next">›</a>
    		<a class="close">×</a>
    		<a class="play-pause"></a>
    		<ol class="indicator"></ol>
		</div>
		<div id="links" style="margin-top: -225px; margin-left: 100px;">
    		<a href="images/foundation/20160811_131159.jpg" title="1st">
        		<img width="300px" src="images/foundation/20160811_131159.jpg" alt="1st" />
    		</a>
    		<a href="images/foundation/20160811_131227.jpg" title="1st">
    			<img width="300px" src="images/foundation/20160811_131227.jpg" alt="1st" />
    		</a>
    		<a href="images/foundation/20160811_131233.jpg" title="1st">
    		   <img width="300px" src="images/foundation/20160811_131233.jpg" alt="1st" />
    		</a>
    		<a href="images/foundation/20160811_131243.jpg" title="1st">
        		<img width="300px" src="images/foundation/20160811_131243.jpg" alt="1st" />
    		</a>
    		<a href="images/foundation/20160811_131253.jpg" title="1st">
    			<img width="300px" src="images/foundation/20160811_131253.jpg" alt="1st" />
    		</a>
    		<a href="images/foundation/20160811_131300.jpg" title="1st">
    		   <img width="300px" src="images/foundation/20160811_131300.jpg" alt="1st" />
    		</a>
    		<a href="images/foundation/20160811_131300.jpg" title="1st">
        		<img width="300px" src="images/foundation/20160811_131300.jpg" alt="1st" />
    		</a>
    		<a href="images/foundation/20160811_131321.jpg" title="1st">
    			<img width="300px" src="images/foundation/20160811_131321.jpg" alt="1st" />
    		</a>
    		<a href="images/foundation/20160811_131321.jpg" title="1st">
    		   <img width="300px" src="images/foundation/20160811_131321.jpg" alt="1st" />
    		</a>
    		<a href="images/foundation/20160811_131321.jpg" title="2nd">
        		<img width="300px" src="images/foundation/20160811_131321.jpg" alt="2nd" />
    		</a>
    		<a href="images/foundation/20160811_131348.jpg" title="2nd">
    			<img width="300px" src="images/foundation/20160811_131348.jpg" alt="2nd" />
    		</a>
    		<a href="images/foundation/20160811_131354.jpg" title="2nd">
    		   <img width="300px" src="images/foundation/20160811_131354.jpg" alt="2nd" />
    		</a>
    		<a href="images/foundation/20160811_131400.jpg" title="2nd">
        		<img width="300px" src="images/foundation/20160811_131400.jpg" alt="2nd" />
    		</a>
    		<a href="images/foundation/20160811_131404.jpg" title="2nd">
    			<img width="300px" src="images/foundation/20160811_131404.jpg" alt="2nd" />
    		</a>
    		<a href="images/foundation/20160811_131409.jpg" title="2nd">
    		   <img width="300px" src="images/foundation/20160811_131409.jpg" alt="2nd" />
    		</a>
    		<a href="images/foundation/20160811_131413.jpg" title="2nd">
        		<img width="300px" src="images/foundation/20160811_131413.jpg" alt="2nd" />
    		</a>
    		<a href="images/foundation/20160811_131419.jpg" title="2nd">
    			<img width="300px" src="images/foundation/20160811_131419.jpg" alt="2nd" />
    		</a>
    		<a href="images/foundation/20160811_131424.jpg" title="2nd">
    		   <img width="300px" src="images/foundation/20160811_131424.jpg" alt="2nd" />
    		</a>
    		<a href="images/foundation/20160811_131429.jpg" title="2nd">
    		   <img width="300px" src="images/foundation/20160811_131429.jpg" alt="2nd" />
    		</a>
    		<a href="images/foundation/20160811_131434.jpg" title="2nd">
    		   <img width="300px" src="images/foundation/20160811_131434.jpg" alt="2nd" />
    		</a>
    		<a href="images/foundation/20160811_131438.jpg" title="2nd">
    		   <img width="300px" src="images/foundation/20160811_131438.jpg" alt="2nd" />
    		</a>
    		<a href="images/foundation/20160811_131444.jpg" title="2nd">
    		   <img width="300px" src="images/foundation/20160811_131444.jpg" alt="2nd" />
    		</a>
    		<a href="images/foundation/20160811_131450.jpg" title="2nd">
    		   <img width="300px" src="images/foundation/20160811_131450.jpg" alt="2nd" />
    		</a>
    		<a href="images/foundation/20160811_131454.jpg" title="2nd">
    		   <img width="300px" src="images/foundation/20160811_131454.jpg" alt="2nd" />
    		</a>
    		<a href="images/foundation/20160811_131459.jpg" title="2nd">
    		   <img width="300px" src="images/foundation/20160811_131459.jpg" alt="2nd" />
    		</a>
		</div>
		<script src="javascript/blueimp-gallery.min.js"></script>
		<script>
			document.getElementById('links').onclick = function (event) {
    			event = event || window.event;
    			var target = event.target || event.srcElement,
         	link = target.src ? target.parentNode : target,
         	options = {index: link, event: event},
         	links = this.getElementsByTagName('a');
    			blueimp.Gallery(links, options);
			};
		</script>
	<?php
		include "htmlCbody.php";
	?>
<?php
	include "close_html.php";
?>
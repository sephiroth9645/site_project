<?php
	include "open_html.php";
?>
	<?php
		include "htmlObody.php";
		$user = $_COOKIE["user"];
		$loadCharacter = file("gameSaves/".$user.".txt");
	?>
		<link rel="stylesheet" type="text/css" href="css/game.css" />
		<script src="javascript/questingGame.js">
		</script>
		<form>
			<div id="gameAround">
				<div id="save">
					<button type="button" id="btnSave" >Save Game</button><button type="button" id="close">[x]</button>
				</div>
				<div id="character">
					<div>
						<label id="lblName" >Name:</label>&nbsp;<input type="text" id="txtName" readonly="readonly" value="<?php echo $loadCharacter[1];?>" />
					</div>
					<div>
						<input type="text" id="txtClass" readonly="readonly" value="<?php echo $loadCharacter[2]; ?>" />
					</div>
					<div>
						<input type="text" id="txtSpecies" readonly="readonly" value="<?php echo $loadCharacter[3]; ?>" />
					</div>
				</div>
				<div>
					<div>
						<label id="lblLvl" >lvl:</label>&nbsp;&nbsp;<input type="text" id="txtLvl" readonly="readonly" />
					</div>
				</div>
				<div id="stats">
					<div>
						<label id="lblStr" >str:</label>&nbsp;<input type="text" id="str" name="str" readonly="readonly" value="<?php echo $loadCharacter[4]; ?>" />
					</div>
					<div>
						<label id="lblCon">con:</label>&nbsp;<input type="text" id="con" name="con" readonly="readonly" value="<?php echo $loadCharacter[5]; ?>" />
					</div>
					<div>
						<label id="lblDex">dex:</label>&nbsp;<input type="text" id="dex" name="dex" readonly="readonly" value="<?php echo $loadCharacter[6]; ?>" />
					</div>
					<div>
						<label id="lblIntele">int:</label>&nbsp;<input type="text" id="intele" name="intele" readonly="readonly" value="<?php echo $loadCharacter[7]; ?>" />
					</div>
					<div>
						<label id="lblWis">wis:</label>&nbsp;<input type="text" id="wis" name="wis" readonly="readonly" value="<?php echo $loadCharacter[8]; ?>" />
					</div>
					<div>
						<label id="lblCha">cha:</label>&nbsp;<input type="text" id="cha" name="cha" readonly="readonly" value="<?php echo $loadCharacter[9]; ?>" />
					</div>
					<div>
						<label id="lblLuk">Luck:</label>&nbsp;<input type="text" id="luk" name="luk" readonly="readonly" value="<?php echo $loadCharacter[10]; ?>" />
					</div>
				</div>
				<div id="">
 					<div>
						<label id="lblExp">exp:</label>&nbsp;<input type="text" id="exp" name="exp" readonly="readonly" value="<?php echo $loadCharacter[12]; ?>" hidden />
					</div>
					<div id="expBar">
						<progress id="prgExp" value="0" max="100"></progress>
					</div>
				</div>
				<div id="power">
					<div>
						<label id="lblHp">hp:</label>&nbsp;<input type="text" id="hp" name="hp" readonly="readonly" value="<?php echo $loadCharacter[13]; ?>" />
					</div>
					<div>
						<label id="lblMp">mp:</label>&nbsp;<input type="text" id="mp" name="mp" readonly="readonly" value="<?php echo $loadCharacter[14]; ?>" />
					</div>
				</div>
				<div id="slayerBar">
					<div>
					<input type="text" id="randomMonster" readonly="readonly" />
					</div>
					<progress id="prgSlayer" value="0" max="100"></progress>
				</div>
				<div id="itemBar">
					<div>
						<input type="text" id="monsterItem" readonly="readonly" />
					</div>
					<div>
						<input type="text" id="currency" readonly="readonly" />
					</div>
				</div>
				<div id="questBar">
					<progress id="prgQuest" value="0" max="100"></progress>
				</div>
				<div id="plotBar">
					<progress id="prgPlot" value="0" max="100"></progress>
				</div>
			</div>
		</form>
	<?php
		include "htmlCbody.php";
	?>
<?php
	include "close_html.php";
?>

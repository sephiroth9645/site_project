		<?php
			include "connect.php";
            $sqlLogin = mysqli_query($con, "SELECT User_Name FROM user");

            $row = mysqli_fetch_assoc($sqlLogin);
                 
            @setcookie("user", $row);
 
               $conn = mysqli_query($con, "SSELECT ID FROM `user` Select CURRENT_USER");
               $row2 = mysqli_fetch_assoc($conn);
		?>
		<div>
			<img src="user_file.php?ID=<?php echo $row2['ID']; ?>" width="125px" height="100px" id="image1"/>
			<br />
					</div>
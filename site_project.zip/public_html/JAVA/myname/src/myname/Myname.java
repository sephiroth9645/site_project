/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myname;

/**
 *
 * @author michael
 */
public class Myname {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.print("Michael Castro\n");
        
        String name = "Michael Castro\n";
        System.out.printf("%s", name);
        
        System.out.println("Michael Castro");
    }
    
}

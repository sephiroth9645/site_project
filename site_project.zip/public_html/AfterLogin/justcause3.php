<?php
	include "open_html.php";
?>
	<?php
		include "htmlObody.php";
	?>
			   <link rel="stylesheet" href="css/blueimp-gallery.min.css">
		<!-- The Gallery as lightbox dialog, should be a child element of the document body -->
		<div id="blueimp-gallery" class="blueimp-gallery">
    		<div class="slides"></div>
    		<h3 class="title"></h3>
    		<a class="prev">‹</a>
    		<a class="next">›</a>
    		<a class="close">×</a>
    		<a class="play-pause"></a>
    		<ol class="indicator"></ol>
		</div>
		<div id="links" style="margin-top: 40px; margin-left: 85px;">
    		<a href="images/PS4/SHARE/Screenshots/Just Cause 3/Bakers_Dozen.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Just Cause 3/Bakers_Dozen.jpg" alt="Bakers Dozen" />
    		</a>
			<a href="images/PS4/SHARE/Screenshots/Just Cause 3/Blowing_Up_Windmills.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Just Cause 3/Blowing_Up_Windmills.jpg" alt="Blowing up Windmills" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Just Cause 3/Cima_Leon.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Just Cause 3/Cima_Leon.jpg" alt="Cima Leon" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Just Cause 3/Costa_Sud.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Just Cause 3/Costa_Sud.jpg" alt="Costa Sud" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Just Cause 3/Earth_Wind_And_Sea.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Just Cause 3/Earth_Wind_And_Sea.jpg" alt="Earth Wind and Sea" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Just Cause 3/Enjoy_Homecoming.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Just Cause 3/Enjoy_Homecoming.jpg" alt="Enjoy Homecoming" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Just Cause 3/F_Missle.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Just Cause 3/F_Missle.jpg" alt="Missle" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Just Cause 3/Fisrt_Encounter.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Just Cause 3/Fisrt_Encounter.jpg" alt="First Encounter" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Just Cause 3/Grappler.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Just Cause 3/Grappler.jpg" alt="Grappler" />
    		</a>
			<a href="images/PS4/SHARE/Screenshots/Just Cause 3/Hide_aways.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Just Cause 3/Hide_aways.jpg" alt="Hide Aways" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Just Cause 3/Just Cause 3_20151223013158.jpg" title="Face Slap">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Just Cause 3/Just Cause 3_20151223013158.jpg" alt="Face Slap" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Just Cause 3/Just Cause 3_20151223105339.jpg" title="Paused">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Just Cause 3/Just Cause 3_20151223105339.jpg" alt="Paused" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Just Cause 3/Just_Causin_Caos.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Just Cause 3/Just_Causin_Caos.jpg" alt="Just Causin Caos" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Just Cause 3/Middle_Name.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Just Cause 3/Middle_Name.jpg" alt="Middle Name" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Just Cause 3/Montana.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Just Cause 3/Montana.jpg" alt="Montana" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Just Cause 3/Offensive.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Just Cause 3/Offensive.jpg" alt="Offensive" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Just Cause 3/Porto_Vina.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Just Cause 3/Porto_Vina.jpg" alt="Porto Vina" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Just Cause 3/Take_That_You_Pipeline.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Just Cause 3/Take_That_You_Pipeline.jpg" alt="Take That You Pipeline" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Just Cause 3/Taming_The_Dracon.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Just Cause 3/Taming_The_Dracon.jpg" alt="Taming the Dracon" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Just Cause 3/Top_Of_The_World.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Just Cause 3/Top_Of_The_World.jpg" alt="Top of the World" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Just Cause 3/Vive.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Just Cause 3/Vive.jpg" alt="Vive" />
    		</a>
    		<a href="images/PS4/SHARE/Screenshots/Just Cause 3/What_A_Diaster.jpg" title="">
        		<img width="300px" src="images/PS4/SHARE/Screenshots/Just Cause 3/What_A_Diaster.jpg" alt="What a Disaster" />
    		</a>
		</div>
		<script src="javascript/blueimp-gallery.min.js"></script>
		<script>
			document.getElementById('links').onclick = function (event) {
    			event = event || window.event;
    			var target = event.target || event.srcElement,
         	link = target.src ? target.parentNode : target,
         	options = {index: link, event: event},
         	links = this.getElementsByTagName('a');
    			blueimp.Gallery(links, options);
			};
		</script>
	<?php
		include "htmlCbody.php";
	?>
<?php
	include "close_html.php";
?>
setTimeout(killMonster, 50);
var i = 0;
var lvl = 1;

window.onload = function() {
	setInterval(killMonster, 50);
}

function killMonster(){
	let slayer = document.getElementById("prgSlayer");
	let txtLvl = document.getElementById("txtLvl");
	if(i >= 100 && slayer.value >= 100){
		i = 0;
		slayer.value = i;
		exp();
		randomMonster();
		//quest();
		//plot();
	}else{
		i++;
		slayer.value++;
	}
}

function exp(){
	let gainExp = document.getElementById("prgExp");
	lvl = 1;
	if(gainExp.value >= 100){
		gainExp.value = i;
		txtLvl.value++;
		chrStats();
	}else{
		gainExp.value += 0.25;
	}
}

function chrStats(){
	let chrClass = document.getElementById("txtClass");
	let str = document.getElementById("str");
	let con = document.getElementById("con");
	let dex = document.getElementById("dex");
	let wis = document.getElementById("wis");
	let intele = document.getElementById("intele");
	let cha = document.getElementById("cha");
	let luk = document.getElementById("luk");
	if(chrClass.value == "Blood Mage"){
		wis.value++;
		intele.value++;
		cha.value++;
		if(txtLvl.value & 1){
		}else{
			str.value++;
			con.value++;
			dex.value++;
			luk.value++;
		}
	}
}

function currency(){
	let cur = document.getElementById("currency");
	cur.value++;
}

function quest(){
	let quest = document.getElementById("prgQuest");
	if(quest.value >= 100){
		quest.value = i;
	}else{
		quest.value += 0.025;
	}
}

function plot(){
	let act = document.getElementById("prgPlot");
	if(act.value >= 100){
		act.value = 0;
	}else{
		act.value += 0.005;
	}
}

function randomMonster(){
	let xhr = new XMLHttpRequest();
	let monster = document.getElementById("randomMonster");
	let item = document.getElementById("monsterItem");
	xhr.onreadystatechange = function(){
		if(xhr.readyState == 4 && xhr.status == 200){
			let xhrMonster = xhr.responseText;
			let monsterValue = xhrMonster.split('|$|');
			if(monster.value == "" || monster.value == "Looking for monsters to slay."){
				monster.value = monsterValue[0];
				item.value = monsterValue[1];
			}else{
				monster.value = "Looking for monsters to slay.";
				item.value = "Sold " + item.value + " for " + 1 + " gold.";
				currency();
			}
		}
	}
	xhr.open("GET", "php_files/monster_database.php");
	xhr.send(null);
}

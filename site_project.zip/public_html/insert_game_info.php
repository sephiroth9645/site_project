<?php
	include "open_html.php";
?>
	<?php
		include "htmlObody.php";
	?>
	
			<?php
   		include "PHP_Classes/more_stuff/Insert_Image.class.php";
       
		   if(isset($_POST["submit"]))
   			{
		   
       	$gameName = $_POST['gameName'];
       	$gameStudio = $_POST['gameStudio'];
       	$releaseDate = $_POST['releaseDate'];
					$gameConsole = $_POST['console'];
					
       	$reg = new Insert_Image($gameName, $gameStudio, $releaseDate, $gameConsole);
   			    If(isset($gameName) && isset($gameStudio) && isset($releaseDate) && isset($gameConsole))
       		{
          		 $reg->getInsertImage($gameName, $gameStudio, $releaseDate, $gameConsole);
        		}
    	  }
		?>
		
		<form method="post">
				<table>
					<tr>
						<td>
							Game Name:
						</td>
						<td>
							<input type="text" name="gameName" />
						</td>
					</tr>
					<tr>
						<td>
							Game Studio:
						</td>
						<td>
							<input type="text" name="gameStudio" />
						</td>
					</tr>
					<tr>
						<td>
							Release Date:
						</td>
						<td>
							<input type="date" name="releaseDate" />
						</td>
					</tr>
					<tr>
						<td>
							Console:
						</td>
						<td>
							<input type="input" name="console" />
						</td>
					</tr>
					<tr>
						<td>
							<input type="file" name="file" />
						</td>
					</tr>
					<tr>
						<td>
							<input type="submit" value="submit" name="submit" />
						</td>
					</tr>
				</table>
		</form>
	<?php
		include "htmlCbody.php";
	?>
<?php
	include "close_html.php";
?>



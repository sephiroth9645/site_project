<?php
			$conn = mysqli_connect("localhost", "root", "", "stealthgames");
			$result = mysqli_query($conn, "SELECT user_ID, user_Image FROM create_user"); 
?>
<?php
	$con = mysqli_connect("localhost", "root", "", "stealthgames");
	$item = mysqli_query($con, "SELECT monster_Name, monster_Item FROM monsters ORDER BY monster_Name");
	$drop = mysqli_fetch_assoc($item);

	print $drop[monster_Item];
?>

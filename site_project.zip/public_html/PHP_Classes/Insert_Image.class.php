<?php
	include "connect.php";
?>

<?php
class Insert_Image
   {

       private $gameName;
       private $gameStudio;
       private $gameRelease;
       private $gameConsole;

       const  USER = "a8068632_root";
       const  SERVER = "mysql13.000webhost.com";
       const PASS = "mCastro131";
       const DB = "a8068632_info";
       
       private $sqlRegister;
       
       function __construct($name, $studio, $release, $console)
       {
           $this->gameName = $name;
           $this->gameStudio = $studio;
           $this->gameRelease = $release;
           $this->gameConsole = $console;

           $this->query = mysqli_connect(self::SERVER, self::USER, self::PASS, self::DB);
           
            if(mysqli_connect_errno())
           {
               echo "Failed to connect to MySQL: " . mysqli_connect_error();
           }
        }
        
        function setGameName($name)
        {
            $this->gameName = $name;
        }
        
        function setGameStudio($studio)
        {
            $this->gameStudio = $studio;
        }
         
         function setGameRelease($release)
         {
             $this->gameRelease = $release;
         }
         
         function setGameConsole($console){
						$this->gameConsole = $console;
         }
          
        function getInsertImage($name, $studio, $release, $console)
        {
             $this->gameName = $name;
             $this->gameStudio = $studio;
             $this->gameRelease = $release;
             $this->gameConsole = $console;
             
             $sqlRegister = mysqli_query($this->query, "INSERT INTO games(Game_Name, Publisher, console, Release_Date) VALUES ('$this->gameName', '$this->gameStudio', '$this->gameConsole', '$this->gameRelease')");
				 }
}

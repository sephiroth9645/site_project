<?php
	 include "display_screen_shots.php";
	 if($comment = mysqli_fetch_assoc($result)){
		?>
			<table>
				<tr>
					<td>
						<?php
				 			echo $_COOKIE["user"];
				 		?>
				 	</td>
					<td>
						<img src="data:image/jpeg;base64, <?php echo base64_encode($comment['user_Image']); ?>" width="50px" height="50px" id="image1"/>
					</td>
				</tr>
			</table>
		<?php
		}
	 	else{
	 		echo "We broke something fix it...";
	 	}
?>

<?php
	$con = mysqli_connect("localhost", "root", "", "stealthgames") or die (mysqli_errno);
	$randomMonster = mysqli_query($con, "SELECT * FROM monsters ORDER BY RAND()");
	$monsterRan = mysqli_fetch_assoc($randomMonster);
	
	print "Slaying... " . $monsterRan["monster_Name"] . '|$|' . $monsterRan["monster_Item"];
?>

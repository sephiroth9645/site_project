<?php	
	if(count($_FILES) > 0) {
		if(is_uploaded_file($_FILES['image']['tmp_name'])) {
			mysql_connect("localhost", "root", "");
			$database_name = "info";
			mysql_select_db($database_name);
			$imgData =addslashes(file_get_contents($_FILES['image']['tmp_name']));
			$imageProperties = getimagesize($_FILES['image']['tmp_name']);
			$sql = "INSERT INTO game_image(type , Game_Image) VALUES ('{$imageProperties['mime']}', '{$imgData}')";
			$current_id = mysql_query($sql) or die("<b>Error:</b> Problem on Image Insert<br/>" . mysql_error());
	}
}
?>
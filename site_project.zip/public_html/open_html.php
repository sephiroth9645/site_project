<?php
	$con = mysqli_connect("localhost", "root", "", "stealthgames");
?>


<!DOCTYPE html>

<html>
    <head>
            <meta charset="utf-8" />
            <link rel="stylesheet" href="css/blueimp-gallery.min.css" />

            <title>Stealth Games</title>
            
            <script src="javascript/navi.js" ></script>
            <style type="text/css">
                body {
                    background-color: #f5f5f5;
                }

                #name {
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    font-size: 24px;
                    font-weight: bolder;
                }
                

                footer {
                    font-size: 15px;
                    text-align: center;
                }
            </style>

            <link href="css/body.css" rel="stylesheet" />
            <style type="text/css">
                #hdCanvas {
                    width: 100%;
                }

                h1 {
                    font-size: 4em;
                    color: white;
                    font-family: Arial, Verdana,'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
                    letter-spacing: 4px;
                    pointer-events: none;
                    font-weight: 500;
                    position: absolute;
                    margin-top: -5.75%;
                    left: 0;
                    right: 0;
                    text-align: center;
                    opacity: .5;
                }
            </style>
        </head>
<?php 	include "open_html.php"; ?>	
	<?php
		include "htmlObody.php";
		$show = $_COOKIE["user"];
		$userID = mysqli_query($con, "SELECT user_ID, user_Image FROM create_user WHERE '$show' = user_Name");
		$row = mysqli_fetch_assoc($userID);
		$userIDR = $row["user_ID"];

		if(isset($_POST["submit"])){
			$comment = $_POST["comment"];
			if(!empty($comment)){
				$insertC = mysqli_query($con, "INSERT INTO comment(user_ID, comment_User) VALUES ('$userIDR', '$comment')");
			}else if(empty($comment)){
			}
		}
	?>
	<form enctype="metadata/form-data" method="post">
		<div>
			<?php
				if($row <= mysqli_fetch_assoc($query)){
			?>
			<div>
				<img src="data:image/jpeg;base64, <?php echo base64_encode($row['user_Image']); ?>" style="margin-top: -40px;" width="50px" height="50px" id="image1"/>
			</div>
			<div>
				<?php
					echo ($show);
				?>
			</div>
			<div>
				<textarea name="comment" maxlength="255" id="comment"></textarea>
			</div>
			<div>
				<input type="submit" name="submit" value="comment" />
			</div>				
			<?php
				}
			?>
		</div>
		<div>
			<?php
				include "reply.php";
			?>
		</div>
	</form>
	<?php
		include "htmlCbody.php";
	?>
	<?php
		include "close_html.php";
	?>

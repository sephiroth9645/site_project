<?php
	include 'open_html.php';
?>
	<?php
		include 'htmlObody.php';
	?>
		<?php
			include "php_add_ons/stuff/display_screenshots.php";
		?>
		<form>
			<div id="images_f">
				<?php
					while($row = mysql_fetch_array($result)){
				?>

					<div id="">
						<img src="image_file.php?ID=<?php echo $row['ID']; ?>" width="700px" height="500px" id="image1"/>
					</div>
				<?php
					}
					mysql_close($conn);
				?>
			</div>
		</form>
	<?php
		include 'htmlCbody.php';
	?>
<?php
	include 'close_html.php';
?>
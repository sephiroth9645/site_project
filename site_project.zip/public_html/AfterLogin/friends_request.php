<?php
	include "open_html.php";
?>
	<?php
		include "htmlObody.php";
		
		$search = $_POST["search"];
		$friend = $_POST["friend"];
		$user = $_COOKIE["user"];
	?>
		<form enctype="metadata/form-data" method="post">
			<div>
				<table>
					<tr>
						<td>
							Search:
						</td>
						<td>
							<input type="text" name="friend" maxlength="255" />
						</td>
					</tr>
					<tr>
						<td>
							<input type="submit" name="search" value="search" />
						</td>
					</tr>
				</table>
			</div>
			<div>
				<table>
					<?php
						$userTwo = $_POST["user_ID_Two"];
						$message = $_POST["message"];
						
						$queryUser = mysqli_query($con, "SELECT ID FROM user WHERE User_Name = '$user'");
						
						$moo = mysqli_fetch_assoc($queryUser);						
						
						$mainUserID = $moo["ID"];
						if($userTwo != 0){
							$insert = mysqli_query($con, "INSERT INTO friend_request (User_ID, User_ID_Two, Message) VALUES ('$mainUserID', '$userTwo', '$message')");					
						}
						else{}
						$query = mysqli_query($con, "SELECT * FROM user WHERE User_Name <> '$user'");
						while($row = mysqli_fetch_array($query)){
					?>
					<tr>
						<td>
							<img src="data:image/jpeg;base64, <?php echo base64_encode($row["User_Image"]); ?>" style="width: 100px; height: 100px;"/>
						</td>
						<td>
							<?php
								echo $row["User_Name"];
							?>
						</td>
						<td>
							<input type="submit" name="friend_request" value="friend request" />
						</td>
						<td>
							<input type="hidden" name="message" value="<?php echo $user; ?> has sent you a friends request." />
						</td>
						<td>
							<input type="hidden" name="user_ID_Two" value="<?php echo $row["ID"]; ?>" />
						</td>
					</tr>
					<?php
						}
					?>
				</table>
			</div>
		</form>
	<?php
		include "htmlCbody.php";
	?>
<?php
	include "close_html.php";
?>
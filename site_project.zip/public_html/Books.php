<?php
	include 'open_html.php';
?>
	<?php
		include 'htmlObody.php';
	?>
		<table id="books">
			<?php
				include 'php_add_ons/stuff/connect.php';
				
				$sql = "SELECT * FROM Books ORDER BY Book_Title";
				
				$result = mysqli_query($con, $sql);
				
				while($row = mysqli_fetch_assoc($result)){
			?>
			<tr>
				<td>
					<?php echo $row['Book_Title']; ?>
				</td>
				<td>
					<?php echo $row['Book_Author']; ?>
				</td>
				<td>
					<?php echo $row['Publish_Date']; ?>
				</td>
			</tr>
			<?php
				}
				mysqli_close();
			?>
		</table>
	<?php
		include 'htmlCbody.php';
	?>
<?php
	include 'close_html.php';
?>